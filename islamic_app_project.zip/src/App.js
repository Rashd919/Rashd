import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import * as Location from 'expo-location';
import { Ionicons } from '@expo/vector-icons';

// استيراد الثوابت
import Colors from './constants/colors';
import Config from './constants/config';

// استيراد الشاشات
import HomeScreen from './screens/Home';
import PrayerTimesScreen from './screens/PrayerTimes';
import QiblaScreen from './screens/Qibla';
import QuranScreen from './screens/Quran';
import QuranReaderScreen from './screens/QuranReader';
import QuranAudioScreen from './screens/QuranAudio';
import HadithScreen from './screens/Hadith';
import HadithReaderScreen from './screens/HadithReader';
import MorningAdhkarScreen from './screens/MorningAdhkar';
import EveningAdhkarScreen from './screens/EveningAdhkar';
import SettingsScreen from './screens/Settings';

// إنشاء المتصفحات
const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

// إعداد الإشعارات
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

// مكون القرآن
const QuranStack = () => {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: Colors.primary,
        },
        headerTintColor: Colors.textInverted,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
    >
      <Stack.Screen 
        name="QuranMain" 
        component={QuranScreen} 
        options={{ title: 'القرآن الكريم' }} 
      />
      <Stack.Screen 
        name="QuranReader" 
        component={QuranReaderScreen} 
        options={({ route }) => ({ title: route.params?.title || 'قراءة القرآن' })} 
      />
      <Stack.Screen 
        name="QuranAudio" 
        component={QuranAudioScreen} 
        options={({ route }) => ({ title: route.params?.title || 'الاستماع للقرآن' })} 
      />
    </Stack.Navigator>
  );
};

// مكون الحديث
const HadithStack = () => {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: Colors.primary,
        },
        headerTintColor: Colors.textInverted,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
    >
      <Stack.Screen 
        name="HadithMain" 
        component={HadithScreen} 
        options={{ title: 'الأحاديث النبوية' }} 
      />
      <Stack.Screen 
        name="HadithReader" 
        component={HadithReaderScreen} 
        options={({ route }) => ({ title: route.params?.title || 'قراءة الحديث' })} 
      />
    </Stack.Navigator>
  );
};

// مكون الأذكار
const AdhkarStack = () => {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: Colors.primary,
        },
        headerTintColor: Colors.textInverted,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
    >
      <Stack.Screen 
        name="MorningAdhkar" 
        component={MorningAdhkarScreen} 
        options={{ title: 'أذكار الصباح' }} 
      />
      <Stack.Screen 
        name="EveningAdhkar" 
        component={EveningAdhkarScreen} 
        options={{ title: 'أذكار المساء' }} 
      />
    </Stack.Navigator>
  );
};

// المكون الرئيسي للتطبيق
export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [userLocation, setUserLocation] = useState(null);
  
  // تهيئة التطبيق
  useEffect(() => {
    const initializeApp = async () => {
      try {
        // طلب أذونات الإشعارات
        const { status: notificationStatus } = await Notifications.requestPermissionsAsync();
        
        // طلب أذونات الموقع
        const { status: locationStatus } = await Location.requestForegroundPermissionsAsync();
        
        if (locationStatus === 'granted') {
          const location = await Location.getCurrentPositionAsync({});
          setUserLocation({
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
          });
        }
        
        // تحميل الإعدادات من التخزين المحلي
        const settingsJson = await AsyncStorage.getItem(Config.storage.keys.settings);
        if (settingsJson) {
          const settings = JSON.parse(settingsJson);
          // تطبيق الإعدادات المحفوظة
          // يمكن إضافة المزيد من المنطق هنا لتطبيق الإعدادات
        }
        
        setIsLoading(false);
      } catch (error) {
        console.error('خطأ في تهيئة التطبيق:', error);
        setIsLoading(false);
      }
    };
    
    initializeApp();
  }, []);
  
  // إذا كان التطبيق قيد التحميل، يمكن عرض شاشة البداية
  if (isLoading) {
    return null; // يمكن استبدالها بمكون شاشة البداية
  }
  
  return (
    <SafeAreaProvider>
      <StatusBar style="light" backgroundColor={Colors.primary} />
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={({ route }) => ({
            tabBarIcon: ({ focused, color, size }) => {
              let iconName;
              
              if (route.name === 'Home') {
                iconName = focused ? 'home' : 'home-outline';
              } else if (route.name === 'PrayerTimes') {
                iconName = focused ? 'time' : 'time-outline';
              } else if (route.name === 'Qibla') {
                iconName = focused ? 'compass' : 'compass-outline';
              } else if (route.name === 'Quran') {
                iconName = focused ? 'book' : 'book-outline';
              } else if (route.name === 'Hadith') {
                iconName = focused ? 'document-text' : 'document-text-outline';
              } else if (route.name === 'Adhkar') {
                iconName = focused ? 'heart' : 'heart-outline';
              } else if (route.name === 'Settings') {
                iconName = focused ? 'settings' : 'settings-outline';
              }
              
              return <Ionicons name={iconName} size={size} color={color} />;
            },
            tabBarActiveTintColor: Colors.primary,
            tabBarInactiveTintColor: Colors.textLight,
            headerStyle: {
              backgroundColor: Colors.primary,
            },
            headerTintColor: Colors.textInverted,
            headerTitleStyle: {
              fontWeight: 'bold',
            },
          })}
        >
          <Tab.Screen 
            name="Home" 
            component={HomeScreen} 
            options={{ 
              title: 'الرئيسية',
              tabBarLabel: 'الرئيسية',
            }}
            initialParams={{ userLocation }}
          />
          <Tab.Screen 
            name="PrayerTimes" 
            component={PrayerTimesScreen} 
            options={{ 
              title: 'مواقيت الصلاة',
              tabBarLabel: 'الصلاة',
            }}
            initialParams={{ userLocation }}
          />
          <Tab.Screen 
            name="Qibla" 
            component={QiblaScreen} 
            options={{ 
              title: 'القبلة',
              tabBarLabel: 'القبلة',
            }}
            initialParams={{ userLocation }}
          />
          <Tab.Screen 
            name="Quran" 
            component={QuranStack} 
            options={{ 
              title: 'القرآن',
              tabBarLabel: 'القرآن',
              headerShown: false,
            }}
          />
          <Tab.Screen 
            name="Hadith" 
            component={HadithStack} 
            options={{ 
              title: 'الحديث',
              tabBarLabel: 'الحديث',
              headerShown: false,
            }}
          />
          <Tab.Screen 
            name="Adhkar" 
            component={AdhkarStack} 
            options={{ 
              title: 'الأذكار',
              tabBarLabel: 'الأذكار',
              headerShown: false,
            }}
          />
          <Tab.Screen 
            name="Settings" 
            component={SettingsScreen} 
            options={{ 
              title: 'الإعدادات',
              tabBarLabel: 'الإعدادات',
            }}
          />
        </Tab.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
