// سمة التطبيق الإسلامي

import Colors from './colors';

export default {
  // الخط
  fonts: {
    regular: {
      fontFamily: 'System',
      fontWeight: 'normal',
    },
    medium: {
      fontFamily: 'System',
      fontWeight: '500',
    },
    bold: {
      fontFamily: 'System',
      fontWeight: 'bold',
    },
    light: {
      fontFamily: 'System',
      fontWeight: '300',
    },
  },
  
  // أحجام الخطوط
  fontSize: {
    small: 12,
    medium: 14,
    large: 16,
    xlarge: 18,
    xxlarge: 22,
    xxxlarge: 28,
  },
  
  // الحشو والهوامش
  spacing: {
    tiny: 4,
    small: 8,
    medium: 16,
    large: 24,
    xlarge: 32,
    xxlarge: 48,
  },
  
  // نصف قطر الزوايا
  borderRadius: {
    small: 4,
    medium: 8,
    large: 16,
    round: 9999,
  },
  
  // الظلال
  shadows: {
    small: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.2,
      shadowRadius: 1.41,
      elevation: 2,
    },
    medium: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.23,
      shadowRadius: 2.62,
      elevation: 4,
    },
    large: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.3,
      shadowRadius: 4.65,
      elevation: 8,
    },
  },
  
  // أنماط الأزرار
  buttons: {
    primary: {
      backgroundColor: Colors.primary,
      color: Colors.textInverted,
      borderRadius: 8,
      paddingVertical: 12,
      paddingHorizontal: 16,
    },
    secondary: {
      backgroundColor: Colors.secondary,
      color: Colors.text,
      borderRadius: 8,
      paddingVertical: 12,
      paddingHorizontal: 16,
    },
    outline: {
      backgroundColor: 'transparent',
      color: Colors.primary,
      borderColor: Colors.primary,
      borderWidth: 1,
      borderRadius: 8,
      paddingVertical: 12,
      paddingHorizontal: 16,
    },
    text: {
      backgroundColor: 'transparent',
      color: Colors.primary,
      paddingVertical: 8,
      paddingHorizontal: 8,
    },
  },
  
  // أنماط البطاقات
  cards: {
    default: {
      backgroundColor: Colors.card,
      borderRadius: 8,
      padding: 16,
      marginVertical: 8,
      ...{
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 3,
        elevation: 2,
      },
    },
    flat: {
      backgroundColor: Colors.card,
      borderRadius: 8,
      padding: 16,
      marginVertical: 8,
      borderWidth: 1,
      borderColor: Colors.border,
    },
    prayer: {
      backgroundColor: Colors.card,
      borderRadius: 8,
      padding: 16,
      marginVertical: 8,
      borderLeftWidth: 4,
      ...{
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 2,
        elevation: 1,
      },
    },
  },
  
  // أنماط حقول الإدخال
  inputs: {
    default: {
      backgroundColor: Colors.background,
      borderRadius: 8,
      borderWidth: 1,
      borderColor: Colors.border,
      paddingVertical: 12,
      paddingHorizontal: 16,
      color: Colors.text,
    },
    error: {
      backgroundColor: Colors.background,
      borderRadius: 8,
      borderWidth: 1,
      borderColor: Colors.error,
      paddingVertical: 12,
      paddingHorizontal: 16,
      color: Colors.text,
    },
  },
  
  // زخارف إسلامية
  patterns: {
    header: {
      backgroundColor: Colors.primary,
      height: 120,
      // سيتم إضافة صورة زخرفية إسلامية كخلفية
    },
    footer: {
      backgroundColor: Colors.primary,
      height: 60,
      // سيتم إضافة صورة زخرفية إسلامية كخلفية
    },
  },
};
