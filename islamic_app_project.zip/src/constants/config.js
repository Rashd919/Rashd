// إعدادات التطبيق الإسلامي

export default {
  // معلومات التطبيق
  appName: 'تطبيق إسلامي - الأردن',
  version: '1.0.0',
  
  // إعدادات مواقيت الصلاة
  prayerTimes: {
    // طريقة الحساب (وزارة الأوقاف الأردنية)
    calculationMethod: 'JORDAN_MINISTRY',
    // وقت التذكير قبل الصلاة (بالدقائق)
    reminderBefore: 15,
    // تفعيل الأذان
    adhanEnabled: true,
    // تفعيل الإقامة
    iqamaEnabled: true,
    // وقت الإقامة بعد الأذان (بالدقائق)
    iqamaAfterAdhan: {
      fajr: 20,
      dhuhr: 10,
      asr: 10,
      maghrib: 5,
      isha: 15
    },
    // مصدر الأذان
    adhanSource: 'makkah', // 'makkah', 'madinah', 'alaqsa'
  },
  
  // إعدادات القرآن الكريم
  quran: {
    // القراء المتاحون
    reciters: [
      {
        id: 'sudais',
        name: 'عبد الرحمن السديس',
        server: 'https://server.mp3quran.net/sudais/'
      },
      {
        id: 'maher',
        name: 'ماهر المعيقلي',
        server: 'https://server.mp3quran.net/maher/'
      },
      {
        id: 'balushi',
        name: 'هزاع البلوشي',
        server: 'https://server.mp3quran.net/balushi/'
      },
      {
        id: 'afasy',
        name: 'مشاري العفاسي',
        server: 'https://server.mp3quran.net/afasy/'
      },
      {
        id: 'minshawi',
        name: 'محمد صديق المنشاوي',
        server: 'https://server.mp3quran.net/minshawi/'
      }
    ],
    // القارئ الافتراضي
    defaultReciter: 'maher',
    // حجم الخط
    fontSize: 18,
    // عرض الترجمة
    showTranslation: false,
    // عرض التفسير
    showTafsir: false,
  },
  
  // إعدادات الأذكار
  adhkar: {
    // تذكير بأذكار الصباح
    morningAdhkarTime: '05:00',
    // تذكير بأذكار المساء
    eveningAdhkarTime: '17:00',
    // تفعيل التذكير
    reminderEnabled: true,
  },
  
  // إعدادات واجهة المستخدم
  ui: {
    // تفعيل الوضع المظلم
    darkMode: false,
    // تفعيل الاهتزاز عند النقر
    hapticFeedback: true,
    // تفعيل الصوت عند النقر
    soundEffects: false,
    // حجم الخط العام
    fontSize: 'medium', // 'small', 'medium', 'large'
  },
  
  // إعدادات API
  api: {
    // واجهة برمجة مواقيت الصلاة
    prayerTimesApi: 'https://api.aladhan.com/v1/timingsByCity',
    // واجهة برمجة القرآن الكريم
    quranApi: 'https://api.alquran.cloud/v1',
    // واجهة برمجة الأحاديث
    hadithApi: 'https://api.sunnah.com/v1',
  },
  
  // إعدادات التخزين المحلي
  storage: {
    // مفاتيح التخزين
    keys: {
      prayerTimes: 'islamic_app_prayer_times',
      settings: 'islamic_app_settings',
      bookmarks: 'islamic_app_bookmarks',
      lastRead: 'islamic_app_last_read',
      favorites: 'islamic_app_favorites',
    },
  },
};
