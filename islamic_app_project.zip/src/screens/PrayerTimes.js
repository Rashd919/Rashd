import React from 'react';
import { StyleSheet, View, Text, ScrollView, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

// استيراد الثوابت
import Colors from '../constants/colors';
import Theme from '../constants/theme';

const { width } = Dimensions.get('window');
const isTablet = width >= 768;

const PrayerTimesScreen = ({ route }) => {
  const { userLocation } = route.params || {};
  
  // بيانات مواقيت الصلاة (ستأتي من API في التطبيق الفعلي)
  const prayerTimes = {
    date: '13 أبريل 2025',
    hijriDate: '15 رمضان 1446',
    city: 'عمان، الأردن',
    timings: {
      Fajr: '04:23',
      Sunrise: '05:52',
      Dhuhr: '12:30',
      Asr: '16:10',
      Maghrib: '19:08',
      Isha: '20:38'
    }
  };

  // ترجمة أسماء الصلوات إلى العربية
  const prayerNamesArabic = {
    Fajr: 'الفجر',
    Sunrise: 'الشروق',
    Dhuhr: 'الظهر',
    Asr: 'العصر',
    Maghrib: 'المغرب',
    Isha: 'العشاء'
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {/* بطاقة التاريخ والموقع */}
        <View style={styles.dateLocationCard}>
          <Text style={styles.dateText}>{prayerTimes.date}</Text>
          <Text style={styles.hijriDateText}>{prayerTimes.hijriDate}</Text>
          <Text style={styles.cityText}>{prayerTimes.city}</Text>
        </View>
        
        {/* بطاقات مواقيت الصلاة */}
        <View style={styles.prayerTimesContainer}>
          {Object.entries(prayerTimes.timings).map(([prayer, time]) => (
            <View 
              key={prayer} 
              style={[
                styles.prayerCard,
                isTablet && styles.prayerCardTablet
              ]}
            >
              <View style={styles.prayerIconContainer}>
                <Ionicons 
                  name={getPrayerIcon(prayer)} 
                  size={isTablet ? 36 : 28} 
                  color={Colors.primary} 
                />
              </View>
              <View style={styles.prayerInfoContainer}>
                <Text style={styles.prayerName}>{prayerNamesArabic[prayer]}</Text>
                <Text style={styles.prayerTime}>{time}</Text>
              </View>
            </View>
          ))}
        </View>
        
        {/* معلومات إضافية */}
        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>معلومات عن مواقيت الصلاة</Text>
          <Text style={styles.infoText}>
            يتم حساب مواقيت الصلاة وفقاً لطريقة وزارة الأوقاف الأردنية.
            تعتمد المواقيت على الموقع الجغرافي وتختلف حسب المدينة والتاريخ.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

// دالة لتحديد أيقونة لكل صلاة
const getPrayerIcon = (prayer) => {
  switch (prayer) {
    case 'Fajr':
      return 'sunny-outline';
    case 'Sunrise':
      return 'partly-sunny-outline';
    case 'Dhuhr':
      return 'sunny';
    case 'Asr':
      return 'partly-sunny';
    case 'Maghrib':
      return 'moon-outline';
    case 'Isha':
      return 'moon';
    default:
      return 'time-outline';
  }
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContainer: {
    padding: Theme.spacing.medium,
  },
  dateLocationCard: {
    ...Theme.cards.default,
    alignItems: 'center',
    padding: Theme.spacing.large,
  },
  dateText: {
    fontSize: Theme.fontSize.large,
    color: Colors.text,
    marginBottom: Theme.spacing.tiny,
    textAlign: 'center',
  },
  hijriDateText: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textLight,
    marginBottom: Theme.spacing.medium,
    textAlign: 'center',
  },
  cityText: {
    fontSize: Theme.fontSize.medium,
    color: Colors.primary,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  prayerTimesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: Theme.spacing.medium,
  },
  prayerCard: {
    width: '48%',
    ...Theme.cards.prayer,
    flexDirection: 'row',
    alignItems: 'center',
    padding: Theme.spacing.medium,
    marginBottom: Theme.spacing.medium,
  },
  prayerCardTablet: {
    width: '31%',
    padding: Theme.spacing.large,
  },
  prayerIconContainer: {
    marginRight: Theme.spacing.medium,
  },
  prayerInfoContainer: {
    flex: 1,
  },
  prayerName: {
    fontSize: Theme.fontSize.medium,
    color: Colors.text,
    marginBottom: Theme.spacing.tiny,
  },
  prayerTime: {
    fontSize: Theme.fontSize.large,
    fontWeight: 'bold',
    color: Colors.primary,
  },
  infoCard: {
    ...Theme.cards.default,
    padding: Theme.spacing.large,
    marginTop: Theme.spacing.medium,
  },
  infoTitle: {
    fontSize: Theme.fontSize.large,
    color: Colors.text,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.medium,
    textAlign: 'center',
  },
  infoText: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textLight,
    lineHeight: 24,
    textAlign: 'right',
  },
});

export default PrayerTimesScreen;
