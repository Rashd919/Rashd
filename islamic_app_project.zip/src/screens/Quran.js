import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, FlatList, TouchableOpacity, ActivityIndicator, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

// استيراد الثوابت
import Colors from '../constants/colors';
import Theme from '../constants/theme';

const { width } = Dimensions.get('window');
const isTablet = width >= 768;

const QuranScreen = ({ navigation }) => {
  const [surahs, setSurahs] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  // الحصول على قائمة السور
  useEffect(() => {
    const fetchSurahs = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // في التطبيق الفعلي، سيتم استدعاء API للحصول على قائمة السور
        // هنا نستخدم بيانات ثابتة للتوضيح
        const surahsData = [
          { number: 1, name: 'الفاتحة', englishName: 'Al-Fatiha', numberOfAyahs: 7 },
          { number: 2, name: 'البقرة', englishName: 'Al-Baqara', numberOfAyahs: 286 },
          { number: 3, name: 'آل عمران', englishName: 'Aal-Imran', numberOfAyahs: 200 },
          { number: 4, name: 'النساء', englishName: 'An-Nisa', numberOfAyahs: 176 },
          { number: 5, name: 'المائدة', englishName: 'Al-Maeda', numberOfAyahs: 120 },
          { number: 6, name: 'الأنعام', englishName: 'Al-Anaam', numberOfAyahs: 165 },
          { number: 7, name: 'الأعراف', englishName: 'Al-Araf', numberOfAyahs: 206 },
          { number: 8, name: 'الأنفال', englishName: 'Al-Anfal', numberOfAyahs: 75 },
          { number: 9, name: 'التوبة', englishName: 'At-Tawba', numberOfAyahs: 129 },
          { number: 10, name: 'يونس', englishName: 'Yunus', numberOfAyahs: 109 },
          // يمكن إضافة باقي السور هنا
        ];
        
        setSurahs(surahsData);
        setIsLoading(false);
      } catch (err) {
        console.error('خطأ في الحصول على قائمة السور:', err);
        setError('حدث خطأ في تحميل قائمة السور. يرجى المحاولة مرة أخرى.');
        setIsLoading(false);
      }
    };
    
    fetchSurahs();
  }, []);

  // التنقل إلى شاشة قراءة السورة
  const navigateToSurah = (surah) => {
    navigation.navigate('QuranReader', {
      surahNumber: surah.number,
      title: surah.name,
    });
  };

  // التنقل إلى شاشة الاستماع للسورة
  const navigateToAudio = (surah) => {
    navigation.navigate('QuranAudio', {
      surahNumber: surah.number,
      title: surah.name,
    });
  };

  // عرض عنصر السورة في القائمة
  const renderSurahItem = ({ item }) => (
    <View style={[styles.surahCard, isTablet && styles.surahCardTablet]}>
      <View style={styles.surahNumberContainer}>
        <Text style={styles.surahNumber}>{item.number}</Text>
      </View>
      <View style={styles.surahInfoContainer}>
        <Text style={styles.surahName}>{item.name}</Text>
        <Text style={styles.surahDetails}>
          {item.englishName} • {item.numberOfAyahs} آية
        </Text>
      </View>
      <View style={styles.surahActionsContainer}>
        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => navigateToSurah(item)}
        >
          <Ionicons name="book-outline" size={isTablet ? 28 : 24} color={Colors.primary} />
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => navigateToAudio(item)}
        >
          <Ionicons name="play-outline" size={isTablet ? 28 : 24} color={Colors.primary} />
        </TouchableOpacity>
      </View>
    </View>
  );

  // عرض شاشة التحميل
  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.primary} />
        <Text style={styles.loadingText}>جاري تحميل قائمة السور...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* رأس الصفحة */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>القرآن الكريم</Text>
        <Text style={styles.headerSubtitle}>اقرأ واستمع إلى كلام الله</Text>
      </View>
      
      {/* قائمة السور */}
      <FlatList
        data={surahs}
        renderItem={renderSurahItem}
        keyExtractor={(item) => item.number.toString()}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />
      
      {/* عرض رسالة الخطأ إذا وجدت */}
      {error && (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.background,
  },
  loadingText: {
    marginTop: Theme.spacing.medium,
    color: Colors.text,
    fontSize: Theme.fontSize.medium,
  },
  header: {
    backgroundColor: Colors.primary,
    padding: Theme.spacing.large,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: isTablet ? Theme.fontSize.xxlarge : Theme.fontSize.xlarge,
    color: Colors.textInverted,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.tiny,
  },
  headerSubtitle: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textInverted,
    opacity: 0.8,
  },
  listContainer: {
    padding: Theme.spacing.medium,
  },
  surahCard: {
    ...Theme.cards.default,
    flexDirection: 'row',
    alignItems: 'center',
    padding: Theme.spacing.medium,
    marginBottom: Theme.spacing.medium,
  },
  surahCardTablet: {
    padding: Theme.spacing.large,
  },
  surahNumberContainer: {
    width: isTablet ? 50 : 40,
    height: isTablet ? 50 : 40,
    borderRadius: isTablet ? 25 : 20,
    backgroundColor: Colors.primaryLight,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: Theme.spacing.medium,
  },
  surahNumber: {
    fontSize: isTablet ? Theme.fontSize.large : Theme.fontSize.medium,
    color: Colors.primary,
    fontWeight: 'bold',
  },
  surahInfoContainer: {
    flex: 1,
  },
  surahName: {
    fontSize: isTablet ? Theme.fontSize.large : Theme.fontSize.medium,
    color: Colors.text,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.tiny,
  },
  surahDetails: {
    fontSize: isTablet ? Theme.fontSize.medium : Theme.fontSize.small,
    color: Colors.textLight,
  },
  surahActionsContainer: {
    flexDirection: 'row',
  },
  actionButton: {
    width: isTablet ? 50 : 40,
    height: isTablet ? 50 : 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: Theme.spacing.small,
  },
  errorContainer: {
    padding: Theme.spacing.medium,
    backgroundColor: '#FFEBEE',
    borderRadius: Theme.borderRadius.medium,
    margin: Theme.spacing.medium,
  },
  errorText: {
    color: Colors.error,
    textAlign: 'center',
  },
});

export default QuranScreen;
