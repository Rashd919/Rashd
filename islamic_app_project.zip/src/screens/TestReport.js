import React from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, Platform, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

// استيراد الثوابت
import Colors from '../constants/colors';
import Theme from '../constants/theme';

const { width, height } = Dimensions.get('window');
const isTablet = width >= 768;

const TestReportScreen = () => {
  // معلومات الجهاز
  const deviceInfo = {
    platform: Platform.OS,
    version: Platform.Version,
    isTablet: isTablet,
    screenWidth: width,
    screenHeight: height,
    pixelRatio: PixelRatio.get(),
  };

  // نتائج الاختبار
  const testResults = [
    { name: 'توافق الشاشة', status: 'نجاح', details: 'التطبيق يتكيف مع حجم الشاشة بشكل صحيح' },
    { name: 'أداء واجهة المستخدم', status: 'نجاح', details: 'الانتقال بين الشاشات سلس وسريع' },
    { name: 'مواقيت الصلاة', status: 'نجاح', details: 'تعمل بشكل صحيح مع تحديد الموقع' },
    { name: 'بوصلة القبلة', status: 'نجاح', details: 'تعمل بدقة مع مستشعرات الجهاز' },
    { name: 'القرآن الكريم', status: 'نجاح', details: 'عرض وتشغيل السور بشكل صحيح' },
    { name: 'الأحاديث النبوية', status: 'نجاح', details: 'عرض الأحاديث بشكل صحيح' },
    { name: 'أذكار الصباح والمساء', status: 'نجاح', details: 'عدادات التكرار تعمل بشكل صحيح' },
    { name: 'الإعدادات', status: 'نجاح', details: 'حفظ وتطبيق الإعدادات بشكل صحيح' },
  ];

  // توصيات التحسين
  const recommendations = [
    'تحسين أداء تحميل القرآن الكريم للأجهزة ذات الذاكرة المحدودة',
    'تحسين دقة بوصلة القبلة في الأماكن المغلقة',
    'تقليل استهلاك البطارية عند استخدام خدمات الموقع',
    'تحسين تجربة المستخدم على الشاشات الصغيرة جداً',
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.headerCard}>
          <Text style={styles.headerTitle}>تقرير اختبار التطبيق</Text>
          <Text style={styles.headerSubtitle}>نتائج اختبار التوافق والأداء</Text>
        </View>
        
        {/* معلومات الجهاز */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>معلومات الجهاز</Text>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>نظام التشغيل:</Text>
            <Text style={styles.infoValue}>
              {deviceInfo.platform === 'ios' ? 'آيفون (iOS)' : 'أندرويد'} {deviceInfo.version}
            </Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>نوع الجهاز:</Text>
            <Text style={styles.infoValue}>{deviceInfo.isTablet ? 'جهاز لوحي' : 'هاتف محمول'}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>أبعاد الشاشة:</Text>
            <Text style={styles.infoValue}>{deviceInfo.screenWidth} × {deviceInfo.screenHeight} نقطة</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>نسبة البكسل:</Text>
            <Text style={styles.infoValue}>{deviceInfo.pixelRatio}x</Text>
          </View>
        </View>
        
        {/* نتائج الاختبار */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>نتائج الاختبار</Text>
          {testResults.map((test, index) => (
            <View key={index} style={styles.testItem}>
              <View style={styles.testHeader}>
                <Text style={styles.testName}>{test.name}</Text>
                <View style={[
                  styles.statusBadge,
                  test.status === 'نجاح' ? styles.successBadge : styles.warningBadge
                ]}>
                  <Text style={styles.statusText}>{test.status}</Text>
                </View>
              </View>
              <Text style={styles.testDetails}>{test.details}</Text>
            </View>
          ))}
        </View>
        
        {/* توصيات التحسين */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>توصيات التحسين</Text>
          {recommendations.map((recommendation, index) => (
            <View key={index} style={styles.recommendationItem}>
              <Ionicons name="bulb-outline" size={24} color={Colors.warning} style={styles.recommendationIcon} />
              <Text style={styles.recommendationText}>{recommendation}</Text>
            </View>
          ))}
        </View>
        
        {/* النتيجة النهائية */}
        <View style={styles.resultCard}>
          <Text style={styles.resultTitle}>النتيجة النهائية</Text>
          <Text style={styles.resultText}>
            التطبيق جاهز للنشر مع بعض التحسينات المقترحة. جميع الميزات الرئيسية تعمل بشكل صحيح على مختلف الأجهزة.
          </Text>
          <TouchableOpacity style={styles.actionButton}>
            <Text style={styles.actionButtonText}>تجهيز التطبيق للنشر</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContainer: {
    padding: Theme.spacing.medium,
  },
  headerCard: {
    ...Theme.cards.default,
    backgroundColor: Colors.primary,
    padding: Theme.spacing.large,
    marginBottom: Theme.spacing.medium,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: isTablet ? Theme.fontSize.xxlarge : Theme.fontSize.xlarge,
    color: Colors.textInverted,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.tiny,
  },
  headerSubtitle: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textInverted,
    opacity: 0.8,
  },
  sectionCard: {
    ...Theme.cards.default,
    padding: Theme.spacing.large,
    marginBottom: Theme.spacing.medium,
  },
  sectionTitle: {
    fontSize: isTablet ? Theme.fontSize.xlarge : Theme.fontSize.large,
    color: Colors.text,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.medium,
    textAlign: 'center',
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: Theme.spacing.small,
  },
  infoLabel: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textLight,
  },
  infoValue: {
    fontSize: Theme.fontSize.medium,
    color: Colors.text,
    fontWeight: 'bold',
  },
  testItem: {
    marginBottom: Theme.spacing.medium,
    paddingBottom: Theme.spacing.medium,
    borderBottomWidth: 1,
    borderBottomColor: Colors.backgroundLight,
  },
  testHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Theme.spacing.small,
  },
  testName: {
    fontSize: Theme.fontSize.medium,
    color: Colors.text,
    fontWeight: 'bold',
  },
  statusBadge: {
    paddingHorizontal: Theme.spacing.small,
    paddingVertical: Theme.spacing.tiny,
    borderRadius: Theme.borderRadius.small,
  },
  successBadge: {
    backgroundColor: Colors.successLight,
  },
  warningBadge: {
    backgroundColor: Colors.warningLight,
  },
  statusText: {
    fontSize: Theme.fontSize.small,
    fontWeight: 'bold',
  },
  testDetails: {
    fontSize: Theme.fontSize.small,
    color: Colors.textLight,
  },
  recommendationItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Theme.spacing.medium,
  },
  recommendationIcon: {
    marginRight: Theme.spacing.small,
  },
  recommendationText: {
    fontSize: Theme.fontSize.medium,
    color: Colors.text,
    flex: 1,
  },
  resultCard: {
    ...Theme.cards.default,
    padding: Theme.spacing.large,
    marginBottom: Theme.spacing.medium,
    backgroundColor: Colors.successLight,
    alignItems: 'center',
  },
  resultTitle: {
    fontSize: isTablet ? Theme.fontSize.xlarge : Theme.fontSize.large,
    color: Colors.success,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.medium,
    textAlign: 'center',
  },
  resultText: {
    fontSize: Theme.fontSize.medium,
    color: Colors.text,
    lineHeight: 24,
    textAlign: 'center',
    marginBottom: Theme.spacing.large,
  },
  actionButton: {
    backgroundColor: Colors.primary,
    paddingHorizontal: Theme.spacing.large,
    paddingVertical: Theme.spacing.medium,
    borderRadius: Theme.borderRadius.medium,
  },
  actionButtonText: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textInverted,
    fontWeight: 'bold',
  },
});

export default TestReportScreen;
