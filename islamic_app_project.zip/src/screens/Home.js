import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as Location from 'expo-location';

// استيراد الخدمات
import { getPrayerTimesByCoordinates, getNextPrayer, getRemainingTime } from '../services/prayerTimes';

// استيراد الثوابت
import Colors from '../constants/colors';
import Theme from '../constants/theme';

const HomeScreen = ({ navigation, route }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [prayerTimes, setPrayerTimes] = useState(null);
  const [nextPrayer, setNextPrayer] = useState(null);
  const [remainingTime, setRemainingTime] = useState({ hours: 0, minutes: 0, seconds: 0 });
  const [currentDate, setCurrentDate] = useState('');
  const [currentTime, setCurrentTime] = useState('');
  const [location, setLocation] = useState(route.params?.userLocation || null);
  const [error, setError] = useState(null);

  // تحديث الوقت الحالي
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      
      // تنسيق التاريخ بالعربية
      const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
      setCurrentDate(now.toLocaleDateString('ar-JO', options));
      
      // تنسيق الوقت
      setCurrentTime(
        now.toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      );
      
      // تحديث الوقت المتبقي للصلاة القادمة
      if (nextPrayer) {
        setRemainingTime(getRemainingTime(nextPrayer.time));
      }
    }, 1000);
    
    return () => clearInterval(timer);
  }, [nextPrayer]);

  // الحصول على مواقيت الصلاة
  useEffect(() => {
    const fetchPrayerTimes = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // إذا لم يكن الموقع متاحاً، نحاول الحصول عليه
        if (!location) {
          const { status } = await Location.requestForegroundPermissionsAsync();
          
          if (status !== 'granted') {
            setError('يرجى السماح بالوصول إلى الموقع للحصول على مواقيت الصلاة الدقيقة');
            setIsLoading(false);
            return;
          }
          
          const currentLocation = await Location.getCurrentPositionAsync({});
          setLocation({
            latitude: currentLocation.coords.latitude,
            longitude: currentLocation.coords.longitude,
          });
        }
        
        // الحصول على مواقيت الصلاة بناءً على الموقع
        const times = await getPrayerTimesByCoordinates(location.latitude, location.longitude);
        setPrayerTimes(times);
        
        // تحديد الصلاة القادمة
        const next = getNextPrayer(times);
        setNextPrayer(next);
        
        // تحديث الوقت المتبقي
        if (next) {
          setRemainingTime(getRemainingTime(next.time));
        }
        
        setIsLoading(false);
      } catch (err) {
        console.error('خطأ في الحصول على مواقيت الصلاة:', err);
        setError('حدث خطأ في الحصول على مواقيت الصلاة. يرجى المحاولة مرة أخرى.');
        setIsLoading(false);
      }
    };
    
    fetchPrayerTimes();
  }, [location]);

  // تنسيق الوقت المتبقي
  const formatRemainingTime = () => {
    return `${remainingTime.hours.toString().padStart(2, '0')}:${remainingTime.minutes.toString().padStart(2, '0')}:${remainingTime.seconds.toString().padStart(2, '0')}`;
  };

  // عرض شاشة التحميل
  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.primary} />
        <Text style={styles.loadingText}>جاري تحميل مواقيت الصلاة...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {/* بطاقة التاريخ والوقت */}
        <View style={styles.dateTimeCard}>
          <Text style={styles.dateText}>{currentDate}</Text>
          <Text style={styles.timeText}>{currentTime}</Text>
        </View>
        
        {/* بطاقة الصلاة القادمة */}
        {nextPrayer && (
          <View style={styles.nextPrayerCard}>
            <Text style={styles.nextPrayerTitle}>الصلاة القادمة</Text>
            <Text style={styles.nextPrayerName}>{nextPrayer.name}</Text>
            <Text style={styles.nextPrayerTime}>{nextPrayer.time}</Text>
            <View style={styles.countdownContainer}>
              <Text style={styles.countdownLabel}>متبقي</Text>
              <Text style={styles.countdownTime}>{formatRemainingTime()}</Text>
            </View>
          </View>
        )}
        
        {/* بطاقات الوصول السريع */}
        <View style={styles.quickAccessContainer}>
          <TouchableOpacity 
            style={styles.quickAccessButton}
            onPress={() => navigation.navigate('PrayerTimes')}
          >
            <Ionicons name="time" size={32} color={Colors.primary} />
            <Text style={styles.quickAccessText}>مواقيت الصلاة</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.quickAccessButton}
            onPress={() => navigation.navigate('Qibla')}
          >
            <Ionicons name="compass" size={32} color={Colors.primary} />
            <Text style={styles.quickAccessText}>اتجاه القبلة</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.quickAccessButton}
            onPress={() => navigation.navigate('Quran')}
          >
            <Ionicons name="book" size={32} color={Colors.primary} />
            <Text style={styles.quickAccessText}>القرآن الكريم</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.quickAccessButton}
            onPress={() => navigation.navigate('Hadith')}
          >
            <Ionicons name="document-text" size={32} color={Colors.primary} />
            <Text style={styles.quickAccessText}>الأحاديث</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.quickAccessButton}
            onPress={() => navigation.navigate('Adhkar')}
          >
            <Ionicons name="heart" size={32} color={Colors.primary} />
            <Text style={styles.quickAccessText}>الأذكار</Text>
          </TouchableOpacity>
        </View>
        
        {/* عرض رسالة الخطأ إذا وجدت */}
        {error && (
          <View style={styles.errorContainer}>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContainer: {
    padding: Theme.spacing.medium,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.background,
  },
  loadingText: {
    marginTop: Theme.spacing.medium,
    color: Colors.text,
    fontSize: Theme.fontSize.medium,
  },
  dateTimeCard: {
    ...Theme.cards.default,
    alignItems: 'center',
    padding: Theme.spacing.large,
  },
  dateText: {
    fontSize: Theme.fontSize.large,
    color: Colors.text,
    marginBottom: Theme.spacing.small,
    textAlign: 'center',
  },
  timeText: {
    fontSize: Theme.fontSize.xxxlarge,
    fontWeight: 'bold',
    color: Colors.primary,
    textAlign: 'center',
  },
  nextPrayerCard: {
    ...Theme.cards.prayer,
    alignItems: 'center',
    padding: Theme.spacing.large,
    marginTop: Theme.spacing.medium,
    borderLeftColor: Colors.primary,
  },
  nextPrayerTitle: {
    fontSize: Theme.fontSize.large,
    color: Colors.textLight,
    marginBottom: Theme.spacing.small,
  },
  nextPrayerName: {
    fontSize: Theme.fontSize.xxlarge,
    fontWeight: 'bold',
    color: Colors.primary,
    marginBottom: Theme.spacing.tiny,
  },
  nextPrayerTime: {
    fontSize: Theme.fontSize.xlarge,
    color: Colors.text,
    marginBottom: Theme.spacing.medium,
  },
  countdownContainer: {
    alignItems: 'center',
  },
  countdownLabel: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textLight,
    marginBottom: Theme.spacing.tiny,
  },
  countdownTime: {
    fontSize: Theme.fontSize.xlarge,
    fontWeight: 'bold',
    color: Colors.accent,
  },
  quickAccessContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: Theme.spacing.large,
  },
  quickAccessButton: {
    width: '48%',
    ...Theme.cards.flat,
    alignItems: 'center',
    padding: Theme.spacing.medium,
    marginVertical: Theme.spacing.small,
  },
  quickAccessText: {
    marginTop: Theme.spacing.small,
    fontSize: Theme.fontSize.medium,
    color: Colors.text,
    textAlign: 'center',
  },
  errorContainer: {
    padding: Theme.spacing.medium,
    backgroundColor: '#FFEBEE',
    borderRadius: Theme.borderRadius.medium,
    marginTop: Theme.spacing.large,
  },
  errorText: {
    color: Colors.error,
    textAlign: 'center',
  },
});

export default HomeScreen;
