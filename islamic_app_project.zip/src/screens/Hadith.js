import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, FlatList, TouchableOpacity, ActivityIndicator, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

// استيراد الثوابت
import Colors from '../constants/colors';
import Theme from '../constants/theme';

const { width } = Dimensions.get('window');
const isTablet = width >= 768;

const HadithScreen = ({ navigation }) => {
  const [collections, setCollections] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // الحصول على قائمة كتب الحديث
  useEffect(() => {
    const fetchHadithCollections = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // في التطبيق الفعلي، سيتم استدعاء API للحصول على قائمة كتب الحديث
        // هنا نستخدم بيانات ثابتة للتوضيح
        const collectionsData = [
          { id: 'bukhari', name: 'صحيح البخاري', englishName: 'Sahih al-Bukhari', count: 7563, description: 'أصح كتب الحديث عند أهل السنة والجماعة' },
          { id: 'muslim', name: 'صحيح مسلم', englishName: 'Sahih Muslim', count: 5362, description: 'ثاني أصح كتب الحديث عند أهل السنة والجماعة' },
          { id: 'tirmidhi', name: 'جامع الترمذي', englishName: 'Jami` at-Tirmidhi', count: 3956, description: 'أحد كتب السنن الستة' },
          { id: 'abudawud', name: 'سنن أبي داود', englishName: 'Sunan Abi Dawud', count: 5274, description: 'أحد كتب السنن الستة' },
          { id: 'nasai', name: 'سنن النسائي', englishName: 'Sunan an-Nasa\'i', count: 5662, description: 'أحد كتب السنن الستة' },
          { id: 'ibnmajah', name: 'سنن ابن ماجه', englishName: 'Sunan Ibn Majah', count: 4341, description: 'أحد كتب السنن الستة' },
        ];
        
        setCollections(collectionsData);
        setIsLoading(false);
      } catch (err) {
        console.error('خطأ في الحصول على قائمة كتب الحديث:', err);
        setError('حدث خطأ في تحميل قائمة كتب الحديث. يرجى المحاولة مرة أخرى.');
        setIsLoading(false);
      }
    };
    
    fetchHadithCollections();
  }, []);

  // التنقل إلى شاشة قراءة الأحاديث
  const navigateToCollection = (collection) => {
    navigation.navigate('HadithReader', {
      collectionId: collection.id,
      title: collection.name,
    });
  };

  // عرض عنصر كتاب الحديث في القائمة
  const renderCollectionItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.collectionCard, isTablet && styles.collectionCardTablet]}
      onPress={() => navigateToCollection(item)}
    >
      <View style={styles.collectionHeader}>
        <Text style={styles.collectionName}>{item.name}</Text>
        <View style={styles.countContainer}>
          <Text style={styles.countText}>{item.count}</Text>
          <Text style={styles.countLabel}>حديث</Text>
        </View>
      </View>
      <Text style={styles.collectionEnglishName}>{item.englishName}</Text>
      <Text style={styles.collectionDescription}>{item.description}</Text>
    </TouchableOpacity>
  );

  // عرض شاشة التحميل
  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.primary} />
        <Text style={styles.loadingText}>جاري تحميل كتب الحديث...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* رأس الصفحة */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>الأحاديث النبوية</Text>
        <Text style={styles.headerSubtitle}>من صحيح البخاري ومسلم</Text>
      </View>
      
      {/* قائمة كتب الحديث */}
      <FlatList
        data={collections}
        renderItem={renderCollectionItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />
      
      {/* عرض رسالة الخطأ إذا وجدت */}
      {error && (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.background,
  },
  loadingText: {
    marginTop: Theme.spacing.medium,
    color: Colors.text,
    fontSize: Theme.fontSize.medium,
  },
  header: {
    backgroundColor: Colors.primary,
    padding: Theme.spacing.large,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: isTablet ? Theme.fontSize.xxlarge : Theme.fontSize.xlarge,
    color: Colors.textInverted,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.tiny,
  },
  headerSubtitle: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textInverted,
    opacity: 0.8,
  },
  listContainer: {
    padding: Theme.spacing.medium,
  },
  collectionCard: {
    ...Theme.cards.default,
    padding: Theme.spacing.medium,
    marginBottom: Theme.spacing.medium,
  },
  collectionCardTablet: {
    padding: Theme.spacing.large,
  },
  collectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Theme.spacing.small,
  },
  collectionName: {
    fontSize: isTablet ? Theme.fontSize.xlarge : Theme.fontSize.large,
    color: Colors.text,
    fontWeight: 'bold',
  },
  countContainer: {
    backgroundColor: Colors.primaryLight,
    borderRadius: Theme.borderRadius.small,
    padding: Theme.spacing.small,
    alignItems: 'center',
  },
  countText: {
    fontSize: isTablet ? Theme.fontSize.medium : Theme.fontSize.small,
    color: Colors.primary,
    fontWeight: 'bold',
  },
  countLabel: {
    fontSize: isTablet ? Theme.fontSize.small : Theme.fontSize.tiny,
    color: Colors.primary,
  },
  collectionEnglishName: {
    fontSize: isTablet ? Theme.fontSize.medium : Theme.fontSize.small,
    color: Colors.textLight,
    marginBottom: Theme.spacing.medium,
  },
  collectionDescription: {
    fontSize: Theme.fontSize.medium,
    color: Colors.text,
    lineHeight: 24,
  },
  errorContainer: {
    padding: Theme.spacing.medium,
    backgroundColor: '#FFEBEE',
    borderRadius: Theme.borderRadius.medium,
    margin: Theme.spacing.medium,
  },
  errorText: {
    color: Colors.error,
    textAlign: 'center',
  },
});

export default HadithScreen;
