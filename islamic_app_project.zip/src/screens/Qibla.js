import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, Image, Dimensions, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Location from 'expo-location';
import { Magnetometer } from 'expo-sensors';
import { Ionicons } from '@expo/vector-icons';

// استيراد الثوابت
import Colors from '../constants/colors';
import Theme from '../constants/theme';

// استيراد الخدمات
import { calculateQiblaDirection, calculateDistanceToKaaba } from '../services/qibla';

const { width } = Dimensions.get('window');
const isTablet = width >= 768;

const QiblaScreen = ({ route }) => {
  const { userLocation } = route.params || {};
  
  const [location, setLocation] = useState(userLocation || null);
  const [qiblaDirection, setQiblaDirection] = useState(null);
  const [distance, setDistance] = useState(null);
  const [heading, setHeading] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [subscription, setSubscription] = useState(null);

  // الحصول على الموقع واتجاه القبلة
  useEffect(() => {
    const getLocationAndQibla = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // إذا لم يكن الموقع متاحاً، نحاول الحصول عليه
        if (!location) {
          const { status } = await Location.requestForegroundPermissionsAsync();
          
          if (status !== 'granted') {
            setError('يرجى السماح بالوصول إلى الموقع لتحديد اتجاه القبلة');
            setIsLoading(false);
            return;
          }
          
          const currentLocation = await Location.getCurrentPositionAsync({});
          const newLocation = {
            latitude: currentLocation.coords.latitude,
            longitude: currentLocation.coords.longitude,
          };
          setLocation(newLocation);
          
          // حساب اتجاه القبلة والمسافة
          const direction = calculateQiblaDirection(newLocation.latitude, newLocation.longitude);
          setQiblaDirection(direction);
          
          const dist = calculateDistanceToKaaba(newLocation.latitude, newLocation.longitude);
          setDistance(dist);
        } else {
          // حساب اتجاه القبلة والمسافة باستخدام الموقع المتوفر
          const direction = calculateQiblaDirection(location.latitude, location.longitude);
          setQiblaDirection(direction);
          
          const dist = calculateDistanceToKaaba(location.latitude, location.longitude);
          setDistance(dist);
        }
        
        setIsLoading(false);
      } catch (err) {
        console.error('خطأ في الحصول على الموقع أو حساب اتجاه القبلة:', err);
        setError('حدث خطأ في تحديد اتجاه القبلة. يرجى المحاولة مرة أخرى.');
        setIsLoading(false);
      }
    };
    
    getLocationAndQibla();
  }, [location]);

  // بدء قراءة البوصلة
  useEffect(() => {
    _subscribe();
    return () => _unsubscribe();
  }, []);

  // الاشتراك في قراءات البوصلة
  const _subscribe = () => {
    setSubscription(
      Magnetometer.addListener(data => {
        const angle = calculateHeading(data);
        setHeading(angle);
      })
    );
  };

  // إلغاء الاشتراك في قراءات البوصلة
  const _unsubscribe = () => {
    subscription && subscription.remove();
    setSubscription(null);
  };

  // حساب الاتجاه من قراءات البوصلة
  const calculateHeading = (magnetometerData) => {
    const { x, y } = magnetometerData;
    let angle = Math.atan2(y, x) * (180 / Math.PI);
    if (angle < 0) {
      angle += 360;
    }
    return angle;
  };

  // حساب زاوية الدوران للإبرة
  const getRotationStyle = () => {
    if (qiblaDirection === null || heading === null) return { transform: [{ rotate: '0deg' }] };
    
    // حساب الزاوية النسبية بين اتجاه الجهاز واتجاه القبلة
    const rotation = qiblaDirection - heading;
    
    return {
      transform: [{ rotate: `${rotation}deg` }]
    };
  };

  // عرض شاشة التحميل
  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.primary} />
        <Text style={styles.loadingText}>جاري تحديد اتجاه القبلة...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.contentContainer}>
        {/* بطاقة معلومات القبلة */}
        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>اتجاه القبلة</Text>
          {location && qiblaDirection !== null && (
            <>
              <Text style={styles.directionText}>
                {qiblaDirection.toFixed(1)}° من الشمال
              </Text>
              {distance !== null && (
                <Text style={styles.distanceText}>
                  المسافة إلى الكعبة: {distance.toFixed(0)} كم
                </Text>
              )}
            </>
          )}
        </View>
        
        {/* بوصلة القبلة */}
        <View style={styles.compassContainer}>
          <Image
            source={require('../../assets/images/compass-bg.png')}
            style={styles.compassBackground}
            resizeMode="contain"
          />
          <View style={[styles.needle, getRotationStyle()]}>
            <Ionicons name="arrow-up" size={isTablet ? 80 : 60} color={Colors.primary} />
            <Text style={styles.kaaba}>الكعبة</Text>
          </View>
        </View>
        
        {/* تعليمات الاستخدام */}
        <View style={styles.instructionsCard}>
          <Text style={styles.instructionsTitle}>تعليمات الاستخدام</Text>
          <Text style={styles.instructionsText}>
            1. امسك الجهاز بشكل أفقي موازٍ للأرض.
            {'\n'}
            2. قم بتدوير الجهاز حتى يشير السهم نحو الكعبة.
            {'\n'}
            3. تأكد من عدم وجود مجالات مغناطيسية قوية قريبة.
          </Text>
        </View>
        
        {/* عرض رسالة الخطأ إذا وجدت */}
        {error && (
          <View style={styles.errorContainer}>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        )}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  contentContainer: {
    flex: 1,
    padding: Theme.spacing.medium,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.background,
  },
  loadingText: {
    marginTop: Theme.spacing.medium,
    color: Colors.text,
    fontSize: Theme.fontSize.medium,
  },
  infoCard: {
    ...Theme.cards.default,
    width: '100%',
    alignItems: 'center',
    padding: Theme.spacing.large,
  },
  infoTitle: {
    fontSize: Theme.fontSize.large,
    color: Colors.text,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.medium,
  },
  directionText: {
    fontSize: isTablet ? Theme.fontSize.xxlarge : Theme.fontSize.xlarge,
    color: Colors.primary,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.small,
  },
  distanceText: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textLight,
  },
  compassContainer: {
    width: isTablet ? 400 : 300,
    height: isTablet ? 400 : 300,
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: Theme.spacing.large,
  },
  compassBackground: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  needle: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  kaaba: {
    color: Colors.primary,
    fontSize: Theme.fontSize.small,
    fontWeight: 'bold',
    marginTop: Theme.spacing.tiny,
  },
  instructionsCard: {
    ...Theme.cards.default,
    width: '100%',
    padding: Theme.spacing.large,
  },
  instructionsTitle: {
    fontSize: Theme.fontSize.large,
    color: Colors.text,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.medium,
    textAlign: 'center',
  },
  instructionsText: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textLight,
    lineHeight: 24,
    textAlign: 'right',
  },
  errorContainer: {
    width: '100%',
    padding: Theme.spacing.medium,
    backgroundColor: '#FFEBEE',
    borderRadius: Theme.borderRadius.medium,
    marginTop: Theme.spacing.large,
  },
  errorText: {
    color: Colors.error,
    textAlign: 'center',
  },
});

export default QiblaScreen;
