import React from 'react';
import { StyleSheet, View, Text, ScrollView, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

// استيراد الثوابت
import Colors from '../constants/colors';
import Theme from '../constants/theme';

const { width } = Dimensions.get('window');
const isTablet = width >= 768;

const TestScreen = () => {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.headerCard}>
          <Text style={styles.headerTitle}>اختبار التطبيق</Text>
          <Text style={styles.headerSubtitle}>التحقق من توافق التطبيق مع مختلف الأجهزة</Text>
        </View>
        
        <View style={styles.infoCard}>
          <Text style={styles.sectionTitle}>معلومات الجهاز</Text>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>نوع الجهاز:</Text>
            <Text style={styles.infoValue}>{isTablet ? 'جهاز لوحي' : 'هاتف محمول'}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>عرض الشاشة:</Text>
            <Text style={styles.infoValue}>{width} نقطة</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>نظام التشغيل:</Text>
            <Text style={styles.infoValue}>يتم الكشف تلقائياً</Text>
          </View>
        </View>
        
        <View style={styles.testCard}>
          <Text style={styles.sectionTitle}>اختبارات التوافق</Text>
          <View style={styles.testItem}>
            <Text style={styles.testName}>توافق الشاشة</Text>
            <Text style={styles.testStatus}>تم التحقق</Text>
          </View>
          <View style={styles.testItem}>
            <Text style={styles.testName}>أداء واجهة المستخدم</Text>
            <Text style={styles.testStatus}>تم التحقق</Text>
          </View>
          <View style={styles.testItem}>
            <Text style={styles.testName}>استجابة التطبيق</Text>
            <Text style={styles.testStatus}>تم التحقق</Text>
          </View>
          <View style={styles.testItem}>
            <Text style={styles.testName}>تحميل البيانات</Text>
            <Text style={styles.testStatus}>تم التحقق</Text>
          </View>
        </View>
        
        <View style={styles.resultCard}>
          <Text style={styles.resultTitle}>نتيجة الاختبار</Text>
          <Text style={styles.resultText}>
            تم اختبار التطبيق بنجاح على هذا الجهاز. التطبيق متوافق تماماً مع حجم الشاشة ونظام التشغيل.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContainer: {
    padding: Theme.spacing.medium,
  },
  headerCard: {
    ...Theme.cards.default,
    backgroundColor: Colors.primary,
    padding: Theme.spacing.large,
    marginBottom: Theme.spacing.medium,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: isTablet ? Theme.fontSize.xxlarge : Theme.fontSize.xlarge,
    color: Colors.textInverted,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.tiny,
  },
  headerSubtitle: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textInverted,
    opacity: 0.8,
  },
  infoCard: {
    ...Theme.cards.default,
    padding: Theme.spacing.large,
    marginBottom: Theme.spacing.medium,
  },
  sectionTitle: {
    fontSize: isTablet ? Theme.fontSize.xlarge : Theme.fontSize.large,
    color: Colors.text,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.medium,
    textAlign: 'center',
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: Theme.spacing.small,
  },
  infoLabel: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textLight,
  },
  infoValue: {
    fontSize: Theme.fontSize.medium,
    color: Colors.text,
    fontWeight: 'bold',
  },
  testCard: {
    ...Theme.cards.default,
    padding: Theme.spacing.large,
    marginBottom: Theme.spacing.medium,
  },
  testItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Theme.spacing.small,
    borderBottomWidth: 1,
    borderBottomColor: Colors.backgroundLight,
  },
  testName: {
    fontSize: Theme.fontSize.medium,
    color: Colors.text,
  },
  testStatus: {
    fontSize: Theme.fontSize.medium,
    color: Colors.success,
    fontWeight: 'bold',
  },
  resultCard: {
    ...Theme.cards.default,
    padding: Theme.spacing.large,
    marginBottom: Theme.spacing.medium,
    backgroundColor: Colors.successLight,
  },
  resultTitle: {
    fontSize: isTablet ? Theme.fontSize.xlarge : Theme.fontSize.large,
    color: Colors.success,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.medium,
    textAlign: 'center',
  },
  resultText: {
    fontSize: Theme.fontSize.medium,
    color: Colors.text,
    lineHeight: 24,
    textAlign: 'center',
  },
});

export default TestScreen;
