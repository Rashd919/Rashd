import React from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, Dimensions, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

// استيراد الثوابت
import Colors from '../constants/colors';
import Theme from '../constants/theme';

const { width } = Dimensions.get('window');
const isTablet = width >= 768;

const PublishScreen = () => {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.headerCard}>
          <Text style={styles.headerTitle}>نشر التطبيق</Text>
          <Text style={styles.headerSubtitle}>تجهيز التطبيق للنشر على متاجر التطبيقات</Text>
        </View>
        
        {/* قسم متجر جوجل بلاي */}
        <View style={styles.storeCard}>
          <View style={styles.storeHeader}>
            <Image
              source={require('../../assets/images/google-play.png')}
              style={styles.storeIcon}
              resizeMode="contain"
            />
            <Text style={styles.storeTitle}>متجر جوجل بلاي</Text>
          </View>
          
          <View style={styles.checklistItem}>
            <Ionicons name="checkmark-circle" size={24} color={Colors.success} />
            <Text style={styles.checklistText}>إنشاء حساب مطور (99$ سنوياً)</Text>
          </View>
          
          <View style={styles.checklistItem}>
            <Ionicons name="checkmark-circle" size={24} color={Colors.success} />
            <Text style={styles.checklistText}>تجهيز ملف APK موقع</Text>
          </View>
          
          <View style={styles.checklistItem}>
            <Ionicons name="checkmark-circle" size={24} color={Colors.success} />
            <Text style={styles.checklistText}>إعداد صفحة التطبيق (الوصف، الصور، الخ)</Text>
          </View>
          
          <View style={styles.checklistItem}>
            <Ionicons name="checkmark-circle" size={24} color={Colors.success} />
            <Text style={styles.checklistText}>تصنيف التطبيق وتحديد الفئة العمرية</Text>
          </View>
          
          <TouchableOpacity style={styles.actionButton}>
            <Text style={styles.actionButtonText}>نشر على متجر جوجل بلاي</Text>
          </TouchableOpacity>
        </View>
        
        {/* قسم متجر آب ستور */}
        <View style={styles.storeCard}>
          <View style={styles.storeHeader}>
            <Image
              source={require('../../assets/images/app-store.png')}
              style={styles.storeIcon}
              resizeMode="contain"
            />
            <Text style={styles.storeTitle}>متجر آب ستور</Text>
          </View>
          
          <View style={styles.checklistItem}>
            <Ionicons name="checkmark-circle" size={24} color={Colors.success} />
            <Text style={styles.checklistText}>إنشاء حساب مطور Apple (99$ سنوياً)</Text>
          </View>
          
          <View style={styles.checklistItem}>
            <Ionicons name="checkmark-circle" size={24} color={Colors.success} />
            <Text style={styles.checklistText}>تجهيز ملف IPA موقع</Text>
          </View>
          
          <View style={styles.checklistItem}>
            <Ionicons name="checkmark-circle" size={24} color={Colors.success} />
            <Text style={styles.checklistText}>إعداد صفحة التطبيق (الوصف، الصور، الخ)</Text>
          </View>
          
          <View style={styles.checklistItem}>
            <Ionicons name="checkmark-circle" size={24} color={Colors.success} />
            <Text style={styles.checklistText}>تصنيف التطبيق وتحديد الفئة العمرية</Text>
          </View>
          
          <TouchableOpacity style={styles.actionButton}>
            <Text style={styles.actionButtonText}>نشر على متجر آب ستور</Text>
          </TouchableOpacity>
        </View>
        
        {/* قسم المواد التسويقية */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>المواد التسويقية</Text>
          
          <View style={styles.marketingItem}>
            <Ionicons name="checkmark-circle" size={24} color={Colors.success} />
            <View style={styles.marketingContent}>
              <Text style={styles.marketingTitle}>أيقونة التطبيق</Text>
              <Text style={styles.marketingDescription}>أيقونة بدقة عالية بأحجام مختلفة لكل متجر</Text>
            </View>
          </View>
          
          <View style={styles.marketingItem}>
            <Ionicons name="checkmark-circle" size={24} color={Colors.success} />
            <View style={styles.marketingContent}>
              <Text style={styles.marketingTitle}>لقطات الشاشة</Text>
              <Text style={styles.marketingDescription}>لقطات شاشة للهواتف والأجهزة اللوحية بأحجام مختلفة</Text>
            </View>
          </View>
          
          <View style={styles.marketingItem}>
            <Ionicons name="checkmark-circle" size={24} color={Colors.success} />
            <View style={styles.marketingContent}>
              <Text style={styles.marketingTitle}>فيديو ترويجي</Text>
              <Text style={styles.marketingDescription}>فيديو قصير يعرض ميزات التطبيق الرئيسية</Text>
            </View>
          </View>
          
          <View style={styles.marketingItem}>
            <Ionicons name="checkmark-circle" size={24} color={Colors.success} />
            <View style={styles.marketingContent}>
              <Text style={styles.marketingTitle}>وصف التطبيق</Text>
              <Text style={styles.marketingDescription}>وصف مفصل للتطبيق مع الكلمات المفتاحية المناسبة</Text>
            </View>
          </View>
        </View>
        
        {/* قسم الخطوات النهائية */}
        <View style={styles.finalCard}>
          <Text style={styles.finalTitle}>الخطوات النهائية</Text>
          <Text style={styles.finalText}>
            تم تجهيز التطبيق للنشر على متاجر التطبيقات. يمكنك الآن إنشاء حسابات المطور ونشر التطبيق على متجري جوجل بلاي وآب ستور.
          </Text>
          <TouchableOpacity style={styles.finalButton}>
            <Text style={styles.finalButtonText}>تسليم التطبيق النهائي</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContainer: {
    padding: Theme.spacing.medium,
  },
  headerCard: {
    ...Theme.cards.default,
    backgroundColor: Colors.primary,
    padding: Theme.spacing.large,
    marginBottom: Theme.spacing.medium,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: isTablet ? Theme.fontSize.xxlarge : Theme.fontSize.xlarge,
    color: Colors.textInverted,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.tiny,
  },
  headerSubtitle: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textInverted,
    opacity: 0.8,
  },
  storeCard: {
    ...Theme.cards.default,
    padding: Theme.spacing.large,
    marginBottom: Theme.spacing.medium,
  },
  storeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Theme.spacing.large,
  },
  storeIcon: {
    width: 40,
    height: 40,
    marginRight: Theme.spacing.medium,
  },
  storeTitle: {
    fontSize: isTablet ? Theme.fontSize.xlarge : Theme.fontSize.large,
    color: Colors.text,
    fontWeight: 'bold',
  },
  checklistItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Theme.spacing.medium,
  },
  checklistText: {
    fontSize: Theme.fontSize.medium,
    color: Colors.text,
    marginLeft: Theme.spacing.medium,
  },
  actionButton: {
    backgroundColor: Colors.primary,
    paddingVertical: Theme.spacing.medium,
    borderRadius: Theme.borderRadius.medium,
    alignItems: 'center',
    marginTop: Theme.spacing.medium,
  },
  actionButtonText: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textInverted,
    fontWeight: 'bold',
  },
  sectionCard: {
    ...Theme.cards.default,
    padding: Theme.spacing.large,
    marginBottom: Theme.spacing.medium,
  },
  sectionTitle: {
    fontSize: isTablet ? Theme.fontSize.xlarge : Theme.fontSize.large,
    color: Colors.text,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.large,
    textAlign: 'center',
  },
  marketingItem: {
    flexDirection: 'row',
    marginBottom: Theme.spacing.medium,
  },
  marketingContent: {
    marginLeft: Theme.spacing.medium,
    flex: 1,
  },
  marketingTitle: {
    fontSize: Theme.fontSize.medium,
    color: Colors.text,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.tiny,
  },
  marketingDescription: {
    fontSize: Theme.fontSize.small,
    color: Colors.textLight,
  },
  finalCard: {
    ...Theme.cards.default,
    padding: Theme.spacing.large,
    marginBottom: Theme.spacing.medium,
    backgroundColor: Colors.successLight,
    alignItems: 'center',
  },
  finalTitle: {
    fontSize: isTablet ? Theme.fontSize.xlarge : Theme.fontSize.large,
    color: Colors.success,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.medium,
  },
  finalText: {
    fontSize: Theme.fontSize.medium,
    color: Colors.text,
    textAlign: 'center',
    marginBottom: Theme.spacing.large,
    lineHeight: 24,
  },
  finalButton: {
    backgroundColor: Colors.success,
    paddingHorizontal: Theme.spacing.large,
    paddingVertical: Theme.spacing.medium,
    borderRadius: Theme.borderRadius.medium,
  },
  finalButtonText: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textInverted,
    fontWeight: 'bold',
  },
});

export default PublishScreen;
