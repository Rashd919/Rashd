import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, Switch, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';

// استيراد الثوابت
import Colors from '../constants/colors';
import Theme from '../constants/theme';
import Config from '../constants/config';

const { width } = Dimensions.get('window');
const isTablet = width >= 768;

const SettingsScreen = () => {
  // إعدادات التطبيق
  const [settings, setSettings] = useState({
    notifications: {
      prayerReminders: true,
      adhkarReminders: true,
      adhanSound: true,
    },
    appearance: {
      darkMode: false,
      fontSize: 'medium', // small, medium, large
    },
    prayerTimes: {
      calculationMethod: 'jordan_ministry', // jordan_ministry, umm_al_qura, egyptian, etc.
      asrMethod: 'standard', // standard, hanafi
    },
    quran: {
      defaultReciter: 'mishari_rashid_alafasy',
      arabicTextType: 'uthmani', // uthmani, simple
    },
  });

  // تحميل الإعدادات من التخزين المحلي
  useEffect(() => {
    const loadSettings = async () => {
      try {
        const savedSettings = await AsyncStorage.getItem(Config.storage.keys.settings);
        if (savedSettings) {
          setSettings(JSON.parse(savedSettings));
        }
      } catch (error) {
        console.error('خطأ في تحميل الإعدادات:', error);
      }
    };
    
    loadSettings();
  }, []);

  // حفظ الإعدادات في التخزين المحلي
  const saveSettings = async (newSettings) => {
    try {
      await AsyncStorage.setItem(Config.storage.keys.settings, JSON.stringify(newSettings));
      setSettings(newSettings);
    } catch (error) {
      console.error('خطأ في حفظ الإعدادات:', error);
    }
  };

  // تحديث إعداد محدد
  const updateSetting = (category, key, value) => {
    const newSettings = { ...settings };
    newSettings[category][key] = value;
    saveSettings(newSettings);
  };

  // تحديث إعداد من قائمة خيارات
  const updateOptionSetting = (category, key, value) => {
    const newSettings = { ...settings };
    newSettings[category][key] = value;
    saveSettings(newSettings);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {/* قسم الإشعارات */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>الإشعارات</Text>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>تذكير بمواقيت الصلاة</Text>
            <Switch
              value={settings.notifications.prayerReminders}
              onValueChange={(value) => updateSetting('notifications', 'prayerReminders', value)}
              trackColor={{ false: Colors.textLight, true: Colors.primaryLight }}
              thumbColor={settings.notifications.prayerReminders ? Colors.primary : Colors.textInverted}
            />
          </View>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>تذكير بالأذكار</Text>
            <Switch
              value={settings.notifications.adhkarReminders}
              onValueChange={(value) => updateSetting('notifications', 'adhkarReminders', value)}
              trackColor={{ false: Colors.textLight, true: Colors.primaryLight }}
              thumbColor={settings.notifications.adhkarReminders ? Colors.primary : Colors.textInverted}
            />
          </View>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>صوت الأذان</Text>
            <Switch
              value={settings.notifications.adhanSound}
              onValueChange={(value) => updateSetting('notifications', 'adhanSound', value)}
              trackColor={{ false: Colors.textLight, true: Colors.primaryLight }}
              thumbColor={settings.notifications.adhanSound ? Colors.primary : Colors.textInverted}
            />
          </View>
        </View>
        
        {/* قسم المظهر */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>المظهر</Text>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>الوضع الداكن</Text>
            <Switch
              value={settings.appearance.darkMode}
              onValueChange={(value) => updateSetting('appearance', 'darkMode', value)}
              trackColor={{ false: Colors.textLight, true: Colors.primaryLight }}
              thumbColor={settings.appearance.darkMode ? Colors.primary : Colors.textInverted}
            />
          </View>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>حجم الخط</Text>
            <View style={styles.optionsContainer}>
              <TouchableOpacity
                style={[
                  styles.optionButton,
                  settings.appearance.fontSize === 'small' && styles.optionButtonSelected
                ]}
                onPress={() => updateOptionSetting('appearance', 'fontSize', 'small')}
              >
                <Text style={[
                  styles.optionText,
                  settings.appearance.fontSize === 'small' && styles.optionTextSelected
                ]}>صغير</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.optionButton,
                  settings.appearance.fontSize === 'medium' && styles.optionButtonSelected
                ]}
                onPress={() => updateOptionSetting('appearance', 'fontSize', 'medium')}
              >
                <Text style={[
                  styles.optionText,
                  settings.appearance.fontSize === 'medium' && styles.optionTextSelected
                ]}>متوسط</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.optionButton,
                  settings.appearance.fontSize === 'large' && styles.optionButtonSelected
                ]}
                onPress={() => updateOptionSetting('appearance', 'fontSize', 'large')}
              >
                <Text style={[
                  styles.optionText,
                  settings.appearance.fontSize === 'large' && styles.optionTextSelected
                ]}>كبير</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        
        {/* قسم مواقيت الصلاة */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>مواقيت الصلاة</Text>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>طريقة الحساب</Text>
            <View style={styles.optionsContainer}>
              <TouchableOpacity
                style={[
                  styles.optionButton,
                  settings.prayerTimes.calculationMethod === 'jordan_ministry' && styles.optionButtonSelected
                ]}
                onPress={() => updateOptionSetting('prayerTimes', 'calculationMethod', 'jordan_ministry')}
              >
                <Text style={[
                  styles.optionText,
                  settings.prayerTimes.calculationMethod === 'jordan_ministry' && styles.optionTextSelected
                ]}>وزارة الأوقاف الأردنية</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.optionButton,
                  settings.prayerTimes.calculationMethod === 'umm_al_qura' && styles.optionButtonSelected
                ]}
                onPress={() => updateOptionSetting('prayerTimes', 'calculationMethod', 'umm_al_qura')}
              >
                <Text style={[
                  styles.optionText,
                  settings.prayerTimes.calculationMethod === 'umm_al_qura' && styles.optionTextSelected
                ]}>أم القرى</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.optionButton,
                  settings.prayerTimes.calculationMethod === 'egyptian' && styles.optionButtonSelected
                ]}
                onPress={() => updateOptionSetting('prayerTimes', 'calculationMethod', 'egyptian')}
              >
                <Text style={[
                  styles.optionText,
                  settings.prayerTimes.calculationMethod === 'egyptian' && styles.optionTextSelected
                ]}>الهيئة المصرية</Text>
              </TouchableOpacity>
            </View>
          </View>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>طريقة حساب العصر</Text>
            <View style={styles.optionsContainer}>
              <TouchableOpacity
                style={[
                  styles.optionButton,
                  settings.prayerTimes.asrMethod === 'standard' && styles.optionButtonSelected
                ]}
                onPress={() => updateOptionSetting('prayerTimes', 'asrMethod', 'standard')}
              >
                <Text style={[
                  styles.optionText,
                  settings.prayerTimes.asrMethod === 'standard' && styles.optionTextSelected
                ]}>قياسي (الشافعي)</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.optionButton,
                  settings.prayerTimes.asrMethod === 'hanafi' && styles.optionButtonSelected
                ]}
                onPress={() => updateOptionSetting('prayerTimes', 'asrMethod', 'hanafi')}
              >
                <Text style={[
                  styles.optionText,
                  settings.prayerTimes.asrMethod === 'hanafi' && styles.optionTextSelected
                ]}>حنفي</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        
        {/* قسم القرآن الكريم */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>القرآن الكريم</Text>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>القارئ الافتراضي</Text>
            <View style={styles.optionsContainer}>
              <TouchableOpacity
                style={[
                  styles.optionButton,
                  settings.quran.defaultReciter === 'mishari_rashid_alafasy' && styles.optionButtonSelected
                ]}
                onPress={() => updateOptionSetting('quran', 'defaultReciter', 'mishari_rashid_alafasy')}
              >
                <Text style={[
                  styles.optionText,
                  settings.quran.defaultReciter === 'mishari_rashid_alafasy' && styles.optionTextSelected
                ]}>مشاري راشد العفاسي</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.optionButton,
                  settings.quran.defaultReciter === 'abdul_basit' && styles.optionButtonSelected
                ]}
                onPress={() => updateOptionSetting('quran', 'defaultReciter', 'abdul_basit')}
              >
                <Text style={[
                  styles.optionText,
                  settings.quran.defaultReciter === 'abdul_basit' && styles.optionTextSelected
                ]}>عبد الباسط عبد الصمد</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.optionButton,
                  settings.quran.defaultReciter === 'maher_al_muaiqly' && styles.optionButtonSelected
                ]}
                onPress={() => updateOptionSetting('quran', 'defaultReciter', 'maher_al_muaiqly')}
              >
                <Text style={[
                  styles.optionText,
                  settings.quran.defaultReciter === 'maher_al_muaiqly' && styles.optionTextSelected
                ]}>ماهر المعيقلي</Text>
              </TouchableOpacity>
            </View>
          </View>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>نوع النص العربي</Text>
            <View style={styles.optionsContainer}>
              <TouchableOpacity
                style={[
                  styles.optionButton,
                  settings.quran.arabicTextType === 'uthmani' && styles.optionButtonSelected
                ]}
                onPress={() => updateOptionSetting('quran', 'arabicTextType', 'uthmani')}
              >
                <Text style={[
                  styles.optionText,
                  settings.quran.arabicTextType === 'uthmani' && styles.optionTextSelected
                ]}>عثماني</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.optionButton,
                  settings.quran.arabicTextType === 'simple' && styles.optionButtonSelected
                ]}
                onPress={() => updateOptionSetting('quran', 'arabicTextType', 'simple')}
              >
                <Text style={[
                  styles.optionText,
                  settings.quran.arabicTextType === 'simple' && styles.optionTextSelected
                ]}>بسيط</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        
        {/* معلومات التطبيق */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>معلومات التطبيق</Text>
          <Text style={styles.appInfoText}>التطبيق الإسلامي للأردن</Text>
          <Text style={styles.appInfoText}>الإصدار: 1.0.0</Text>
          <Text style={styles.appInfoText}>تم التطوير بواسطة: فريق مانوس</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContainer: {
    padding: Theme.spacing.medium,
  },
  sectionCard: {
    ...Theme.cards.default,
    padding: Theme.spacing.large,
    marginBottom: Theme.spacing.medium,
  },
  sectionTitle: {
    fontSize: isTablet ? Theme.fontSize.xlarge : Theme.fontSize.large,
    color: Colors.primary,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.medium,
    textAlign: 'center',
  },
  settingItem: {
    marginBottom: Theme.spacing.medium,
  },
  settingLabel: {
    fontSize: Theme.fontSize.medium,
    color: Colors.text,
    marginBottom: Theme.spacing.small,
  },
  optionsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  optionButton: {
    backgroundColor: Colors.backgroundLight,
    borderRadius: Theme.borderRadius.small,
    padding: Theme.spacing.small,
    marginVertical: Theme.spacing.tiny,
    minWidth: '30%',
    alignItems: 'center',
  },
  optionButtonSelected: {
    backgroundColor: Colors.primaryLight,
  },
  optionText: {
    fontSize: Theme.fontSize.small,
    color: Colors.text,
  },
  optionTextSelected: {
    color: Colors.primary,
    fontWeight: 'bold',
  },
  appInfoText: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textLight,
    textAlign: 'center',
    marginBottom: Theme.spacing.small,
  },
});

export default SettingsScreen;
