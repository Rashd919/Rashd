import React, { useState } from 'react';
import { StyleSheet, View, Text, FlatList, TouchableOpacity, ScrollView, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

// استيراد الثوابت
import Colors from '../constants/colors';
import Theme from '../constants/theme';

const { width } = Dimensions.get('window');
const isTablet = width >= 768;

const EveningAdhkarScreen = () => {
  // بيانات أذكار المساء (ستأتي من API أو ملف محلي في التطبيق الفعلي)
  const eveningAdhkar = [
    {
      id: '1',
      text: 'أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ\nاللّهُ لاَ إِلَـهَ إِلاَّ هُوَ الْحَيُّ الْقَيُّومُ لاَ تَأْخُذُهُ سِنَةٌ وَلاَ نَوْمٌ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الأَرْضِ مَن ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلاَّ بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلاَ يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلاَّ بِمَا شَاء وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالأَرْضَ وَلاَ يَؤُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ',
      source: 'البقرة: 255',
      repeat: 1,
      benefit: 'من قالها حين يصبح أجير من الجن حتى يمسي، ومن قالها حين يمسي أجير من الجن حتى يصبح'
    },
    {
      id: '2',
      text: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ\nقُلْ هُوَ اللَّهُ أَحَدٌ * اللَّهُ الصَّمَدُ * لَمْ يَلِدْ وَلَمْ يُولَدْ * وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ',
      source: 'الإخلاص: 1-4',
      repeat: 3,
      benefit: 'من قالها حين يصبح وحين يمسي ثلاث مرات كفته من كل شيء'
    },
    {
      id: '3',
      text: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ\nقُلْ أَعُوذُ بِرَبِّ الْفَلَقِ * مِن شَرِّ مَا خَلَقَ * وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ * وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ * وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ',
      source: 'الفلق: 1-5',
      repeat: 3,
      benefit: 'من قالها حين يصبح وحين يمسي ثلاث مرات كفته من كل شيء'
    },
    {
      id: '4',
      text: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ\nقُلْ أَعُوذُ بِرَبِّ النَّاسِ * مَلِكِ النَّاسِ * إِلَهِ النَّاسِ * مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ * الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ * مِنَ الْجِنَّةِ وَالنَّاسِ',
      source: 'الناس: 1-6',
      repeat: 3,
      benefit: 'من قالها حين يصبح وحين يمسي ثلاث مرات كفته من كل شيء'
    },
    {
      id: '5',
      text: 'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ. رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذِهِ اللَّيْلَةِ وَخَيْرَ مَا بَعْدَهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذِهِ اللَّيْلَةِ وَشَرِّ مَا بَعْدَهَا، رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ، رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ',
      source: 'رواه مسلم',
      repeat: 1,
      benefit: 'دعاء المساء'
    },
    {
      id: '6',
      text: 'اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ',
      source: 'رواه الترمذي',
      repeat: 1,
      benefit: 'من أذكار المساء'
    },
    {
      id: '7',
      text: 'أَمْسَيْنَا عَلَى فِطْرَةِ الْإِسْلَامِ، وَعَلَى كَلِمَةِ الْإِخْلَاصِ، وَعَلَى دِينِ نَبِيِّنَا مُحَمَّدٍ صَلَّى اللهُ عَلَيْهِ وَسَلَّمَ، وَعَلَى مِلَّةِ أَبِينَا إِبْرَاهِيمَ، حَنِيفًا مُسْلِمًا وَمَا كَانَ مِنَ الْمُشْرِكِينَ',
      source: 'رواه أحمد',
      repeat: 1,
      benefit: 'من أذكار المساء'
    }
  ];

  // حالة عدادات التكرار
  const [counters, setCounters] = useState(eveningAdhkar.map(dhikr => dhikr.repeat));

  // تقليل عداد التكرار
  const decrementCounter = (index) => {
    if (counters[index] > 0) {
      const newCounters = [...counters];
      newCounters[index] = newCounters[index] - 1;
      setCounters(newCounters);
    }
  };

  // إعادة ضبط عداد التكرار
  const resetCounter = (index, repeat) => {
    const newCounters = [...counters];
    newCounters[index] = repeat;
    setCounters(newCounters);
  };

  // عرض عنصر الذكر في القائمة
  const renderDhikrItem = ({ item, index }) => (
    <View style={[styles.dhikrCard, isTablet && styles.dhikrCardTablet]}>
      <View style={styles.dhikrHeader}>
        <View style={styles.counterContainer}>
          <Text style={styles.counterText}>{counters[index]}</Text>
          <Text style={styles.counterLabel}>متبقي</Text>
        </View>
        <View style={styles.dhikrActions}>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => decrementCounter(index)}
            disabled={counters[index] === 0}
          >
            <Ionicons 
              name="checkmark-circle" 
              size={isTablet ? 32 : 24} 
              color={counters[index] === 0 ? Colors.success : Colors.primary} 
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => resetCounter(index, item.repeat)}
          >
            <Ionicons name="refresh" size={isTablet ? 32 : 24} color={Colors.primary} />
          </TouchableOpacity>
        </View>
      </View>
      <ScrollView style={styles.dhikrTextContainer}>
        <Text style={styles.dhikrText}>{item.text}</Text>
      </ScrollView>
      <View style={styles.dhikrFooter}>
        <Text style={styles.dhikrSource}>{item.source}</Text>
        <Text style={styles.dhikrRepeat}>التكرار: {item.repeat} {item.repeat > 10 ? 'مرة' : item.repeat > 2 ? 'مرات' : 'مرة'}</Text>
      </View>
      {item.benefit && (
        <View style={styles.benefitContainer}>
          <Text style={styles.benefitLabel}>الفضل:</Text>
          <Text style={styles.benefitText}>{item.benefit}</Text>
        </View>
      )}
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* رأس الصفحة */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>أذكار المساء</Text>
        <Text style={styles.headerSubtitle}>الأذكار المسنونة في المساء</Text>
      </View>
      
      {/* قائمة الأذكار */}
      <FlatList
        data={eveningAdhkar}
        renderItem={renderDhikrItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    backgroundColor: Colors.primary,
    padding: Theme.spacing.large,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: isTablet ? Theme.fontSize.xxlarge : Theme.fontSize.xlarge,
    color: Colors.textInverted,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.tiny,
  },
  headerSubtitle: {
    fontSize: Theme.fontSize.medium,
    color: Colors.textInverted,
    opacity: 0.8,
  },
  listContainer: {
    padding: Theme.spacing.medium,
  },
  dhikrCard: {
    ...Theme.cards.default,
    padding: Theme.spacing.medium,
    marginBottom: Theme.spacing.medium,
  },
  dhikrCardTablet: {
    padding: Theme.spacing.large,
  },
  dhikrHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Theme.spacing.medium,
  },
  counterContainer: {
    backgroundColor: Colors.primaryLight,
    borderRadius: Theme.borderRadius.medium,
    padding: Theme.spacing.medium,
    alignItems: 'center',
    justifyContent: 'center',
    width: isTablet ? 80 : 60,
    height: isTablet ? 80 : 60,
  },
  counterText: {
    fontSize: isTablet ? Theme.fontSize.xlarge : Theme.fontSize.large,
    color: Colors.primary,
    fontWeight: 'bold',
  },
  counterLabel: {
    fontSize: isTablet ? Theme.fontSize.small : Theme.fontSize.tiny,
    color: Colors.primary,
  },
  dhikrActions: {
    flexDirection: 'row',
  },
  actionButton: {
    width: isTablet ? 50 : 40,
    height: isTablet ? 50 : 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: Theme.spacing.small,
  },
  dhikrTextContainer: {
    maxHeight: isTablet ? 200 : 150,
    marginBottom: Theme.spacing.medium,
  },
  dhikrText: {
    fontSize: isTablet ? Theme.fontSize.large : Theme.fontSize.medium,
    color: Colors.text,
    lineHeight: isTablet ? 32 : 26,
    textAlign: 'right',
  },
  dhikrFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Theme.spacing.small,
  },
  dhikrSource: {
    fontSize: Theme.fontSize.small,
    color: Colors.textLight,
    fontStyle: 'italic',
  },
  dhikrRepeat: {
    fontSize: Theme.fontSize.small,
    color: Colors.primary,
    fontWeight: 'bold',
  },
  benefitContainer: {
    backgroundColor: Colors.primaryLight,
    borderRadius: Theme.borderRadius.small,
    padding: Theme.spacing.medium,
  },
  benefitLabel: {
    fontSize: Theme.fontSize.small,
    color: Colors.primary,
    fontWeight: 'bold',
    marginBottom: Theme.spacing.tiny,
  },
  benefitText: {
    fontSize: Theme.fontSize.small,
    color: Colors.text,
    lineHeight: 20,
  },
});

export default EveningAdhkarScreen;
