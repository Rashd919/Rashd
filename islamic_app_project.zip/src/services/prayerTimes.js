// خدمة مواقيت الصلاة

import Config from '../constants/config';

/**
 * الحصول على مواقيت الصلاة بناءً على المدينة والبلد
 * @param {string} city - اسم المدينة
 * @param {string} country - اسم البلد
 * @returns {Promise} وعد يحتوي على مواقيت الصلاة
 */
export const getPrayerTimesByCity = async (city = 'Amman', country = 'Jordan') => {
  try {
    const date = new Date();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    
    const url = `${Config.api.prayerTimesApi}?city=${city}&country=${country}&method=${getCalculationMethodCode()}&month=${month}&year=${year}`;
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.code === 200 && data.status === 'OK') {
      return data.data;
    } else {
      throw new Error('فشل في الحصول على مواقيت الصلاة');
    }
  } catch (error) {
    console.error('خطأ في خدمة مواقيت الصلاة:', error);
    throw error;
  }
};

/**
 * الحصول على مواقيت الصلاة بناءً على الإحداثيات
 * @param {number} latitude - خط العرض
 * @param {number} longitude - خط الطول
 * @returns {Promise} وعد يحتوي على مواقيت الصلاة
 */
export const getPrayerTimesByCoordinates = async (latitude, longitude) => {
  try {
    const date = new Date();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    
    const url = `${Config.api.prayerTimesApi.replace('timingsByCity', 'timingsByLatLong')}?latitude=${latitude}&longitude=${longitude}&method=${getCalculationMethodCode()}&month=${month}&year=${year}`;
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.code === 200 && data.status === 'OK') {
      return data.data;
    } else {
      throw new Error('فشل في الحصول على مواقيت الصلاة');
    }
  } catch (error) {
    console.error('خطأ في خدمة مواقيت الصلاة:', error);
    throw error;
  }
};

/**
 * الحصول على رمز طريقة حساب مواقيت الصلاة
 * @returns {number} رمز طريقة الحساب
 */
const getCalculationMethodCode = () => {
  // طريقة وزارة الأوقاف الأردنية تستخدم طريقة أم القرى مع تعديلات
  // رمز طريقة أم القرى هو 4
  return 4;
};

/**
 * الحصول على الصلاة القادمة ووقتها
 * @param {Object} prayerTimes - كائن يحتوي على مواقيت الصلاة
 * @returns {Object} كائن يحتوي على اسم الصلاة القادمة ووقتها
 */
export const getNextPrayer = (prayerTimes) => {
  if (!prayerTimes || !prayerTimes.timings) {
    return null;
  }
  
  const prayers = [
    { name: 'الفجر', time: prayerTimes.timings.Fajr },
    { name: 'الشروق', time: prayerTimes.timings.Sunrise },
    { name: 'الظهر', time: prayerTimes.timings.Dhuhr },
    { name: 'العصر', time: prayerTimes.timings.Asr },
    { name: 'المغرب', time: prayerTimes.timings.Maghrib },
    { name: 'العشاء', time: prayerTimes.timings.Isha },
  ];
  
  const now = new Date();
  const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
  
  for (const prayer of prayers) {
    // تحويل وقت الصلاة إلى تنسيق 24 ساعة
    const prayerTime = prayer.time.split(' ')[0];
    
    if (currentTime < prayerTime) {
      return {
        name: prayer.name,
        time: prayerTime,
      };
    }
  }
  
  // إذا مرت جميع الصلوات، فالصلاة القادمة هي الفجر في اليوم التالي
  return {
    name: 'الفجر (غداً)',
    time: prayers[0].time.split(' ')[0],
  };
};

/**
 * حساب الوقت المتبقي للصلاة القادمة
 * @param {string} nextPrayerTime - وقت الصلاة القادمة
 * @returns {Object} كائن يحتوي على الساعات والدقائق والثواني المتبقية
 */
export const getRemainingTime = (nextPrayerTime) => {
  if (!nextPrayerTime) {
    return { hours: 0, minutes: 0, seconds: 0 };
  }
  
  const now = new Date();
  const prayerTimeParts = nextPrayerTime.split(':');
  
  const prayerDate = new Date();
  prayerDate.setHours(parseInt(prayerTimeParts[0], 10));
  prayerDate.setMinutes(parseInt(prayerTimeParts[1], 10));
  prayerDate.setSeconds(0);
  
  // إذا كان وقت الصلاة قد مر، أضف يوماً واحداً
  if (prayerDate < now) {
    prayerDate.setDate(prayerDate.getDate() + 1);
  }
  
  const diffMs = prayerDate - now;
  const diffSec = Math.floor(diffMs / 1000);
  
  const hours = Math.floor(diffSec / 3600);
  const minutes = Math.floor((diffSec % 3600) / 60);
  const seconds = diffSec % 60;
  
  return { hours, minutes, seconds };
};
