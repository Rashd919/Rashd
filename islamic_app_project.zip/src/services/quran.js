// خدمة القرآن الكريم

import Config from '../constants/config';

/**
 * الحصول على قائمة السور
 * @returns {Promise} وعد يحتوي على قائمة السور
 */
export const getSurahs = async () => {
  try {
    const url = `${Config.api.quranApi}/surah`;
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.code === 200 && data.status === 'OK') {
      return data.data;
    } else {
      throw new Error('فشل في الحصول على قائمة السور');
    }
  } catch (error) {
    console.error('خطأ في خدمة القرآن:', error);
    throw error;
  }
};

/**
 * الحصول على آيات سورة معينة
 * @param {number} surahNumber - رقم السورة
 * @returns {Promise} وعد يحتوي على آيات السورة
 */
export const getSurahVerses = async (surahNumber) => {
  try {
    const url = `${Config.api.quranApi}/surah/${surahNumber}`;
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.code === 200 && data.status === 'OK') {
      return data.data;
    } else {
      throw new Error(`فشل في الحصول على آيات السورة رقم ${surahNumber}`);
    }
  } catch (error) {
    console.error('خطأ في خدمة القرآن:', error);
    throw error;
  }
};

/**
 * الحصول على تفسير آية معينة
 * @param {number} surahNumber - رقم السورة
 * @param {number} verseNumber - رقم الآية
 * @returns {Promise} وعد يحتوي على تفسير الآية
 */
export const getVerseTafsir = async (surahNumber, verseNumber) => {
  try {
    // استخدام تفسير ابن كثير
    const url = `${Config.api.quranApi}/ayah/${surahNumber}:${verseNumber}/tafsir/ar.kathir`;
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.code === 200 && data.status === 'OK') {
      return data.data;
    } else {
      throw new Error(`فشل في الحصول على تفسير الآية ${verseNumber} من السورة ${surahNumber}`);
    }
  } catch (error) {
    console.error('خطأ في خدمة القرآن:', error);
    throw error;
  }
};

/**
 * الحصول على رابط ملف صوتي لسورة معينة
 * @param {number} surahNumber - رقم السورة
 * @param {string} reciterId - معرف القارئ
 * @returns {string} رابط الملف الصوتي
 */
export const getAudioUrl = (surahNumber, reciterId = Config.quran.defaultReciter) => {
  // البحث عن القارئ في قائمة القراء
  const reciter = Config.quran.reciters.find(r => r.id === reciterId);
  
  if (!reciter) {
    throw new Error(`القارئ ${reciterId} غير موجود`);
  }
  
  // تنسيق رقم السورة بثلاثة أرقام (مثلاً: 001، 012، 114)
  const formattedSurahNumber = surahNumber.toString().padStart(3, '0');
  
  // إنشاء رابط الملف الصوتي
  return `${reciter.server}${formattedSurahNumber}.mp3`;
};

/**
 * البحث في القرآن الكريم
 * @param {string} query - نص البحث
 * @returns {Promise} وعد يحتوي على نتائج البحث
 */
export const searchQuran = async (query) => {
  try {
    const url = `${Config.api.quranApi}/search/${query}/all/ar`;
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.code === 200 && data.status === 'OK') {
      return data.data.matches;
    } else {
      throw new Error(`فشل في البحث عن "${query}"`);
    }
  } catch (error) {
    console.error('خطأ في خدمة القرآن:', error);
    throw error;
  }
};

/**
 * حفظ آخر موضع قراءة
 * @param {number} surahNumber - رقم السورة
 * @param {number} verseNumber - رقم الآية
 * @param {Object} storage - كائن التخزين المحلي
 */
export const saveLastReadPosition = async (surahNumber, verseNumber, storage) => {
  try {
    const lastReadData = {
      surah: surahNumber,
      verse: verseNumber,
      timestamp: new Date().toISOString(),
    };
    
    await storage.setItem(
      Config.storage.keys.lastRead,
      JSON.stringify(lastReadData)
    );
  } catch (error) {
    console.error('خطأ في حفظ موضع القراءة:', error);
    throw error;
  }
};

/**
 * الحصول على آخر موضع قراءة
 * @param {Object} storage - كائن التخزين المحلي
 * @returns {Promise} وعد يحتوي على آخر موضع قراءة
 */
export const getLastReadPosition = async (storage) => {
  try {
    const lastReadData = await storage.getItem(Config.storage.keys.lastRead);
    
    if (lastReadData) {
      return JSON.parse(lastReadData);
    }
    
    // القيمة الافتراضية: سورة الفاتحة، الآية 1
    return {
      surah: 1,
      verse: 1,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.error('خطأ في الحصول على موضع القراءة:', error);
    
    // القيمة الافتراضية في حالة الخطأ
    return {
      surah: 1,
      verse: 1,
      timestamp: new Date().toISOString(),
    };
  }
};
