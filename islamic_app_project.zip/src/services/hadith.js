// خدمة الأحاديث النبوية

import Config from '../constants/config';

/**
 * الحصول على قائمة كتب الحديث المتاحة
 * @returns {Promise} وعد يحتوي على قائمة الكتب
 */
export const getHadithBooks = async () => {
  try {
    const url = `${Config.api.hadithApi}/collections`;
    
    // إضافة رأس التوثيق (قد يكون مطلوباً لبعض واجهات برمجة الأحاديث)
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
    
    const response = await fetch(url, { headers });
    const data = await response.json();
    
    // تصفية الكتب للحصول على صحيح البخاري وصحيح مسلم فقط
    const filteredBooks = data.data.filter(book => 
      book.name === 'صحيح البخاري' || 
      book.name === 'صحيح مسلم' ||
      book.collection === 'bukhari' || 
      book.collection === 'muslim'
    );
    
    return filteredBooks;
  } catch (error) {
    console.error('خطأ في خدمة الأحاديث:', error);
    
    // في حالة فشل الاتصال بالواجهة، نعيد قائمة افتراضية
    return [
      { 
        name: 'صحيح البخاري', 
        collection: 'bukhari',
        hasChapters: true,
        totalHadith: 7563
      },
      { 
        name: 'صحيح مسلم', 
        collection: 'muslim',
        hasChapters: true,
        totalHadith: 7563
      }
    ];
  }
};

/**
 * الحصول على أبواب كتاب حديث معين
 * @param {string} collection - معرف الكتاب (مثل: bukhari، muslim)
 * @returns {Promise} وعد يحتوي على قائمة الأبواب
 */
export const getHadithChapters = async (collection) => {
  try {
    const url = `${Config.api.hadithApi}/collections/${collection}/chapters`;
    
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
    
    const response = await fetch(url, { headers });
    const data = await response.json();
    
    return data.data;
  } catch (error) {
    console.error(`خطأ في الحصول على أبواب ${collection}:`, error);
    throw error;
  }
};

/**
 * الحصول على أحاديث باب معين
 * @param {string} collection - معرف الكتاب
 * @param {number} chapterId - معرف الباب
 * @param {number} page - رقم الصفحة
 * @param {number} limit - عدد الأحاديث في الصفحة
 * @returns {Promise} وعد يحتوي على قائمة الأحاديث
 */
export const getHadithsByChapter = async (collection, chapterId, page = 1, limit = 20) => {
  try {
    const url = `${Config.api.hadithApi}/collections/${collection}/chapters/${chapterId}?page=${page}&limit=${limit}`;
    
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
    
    const response = await fetch(url, { headers });
    const data = await response.json();
    
    return data.data;
  } catch (error) {
    console.error(`خطأ في الحصول على أحاديث الباب ${chapterId} من ${collection}:`, error);
    throw error;
  }
};

/**
 * الحصول على حديث معين بالرقم
 * @param {string} collection - معرف الكتاب
 * @param {number} hadithNumber - رقم الحديث
 * @returns {Promise} وعد يحتوي على الحديث
 */
export const getHadithByNumber = async (collection, hadithNumber) => {
  try {
    const url = `${Config.api.hadithApi}/collections/${collection}/hadiths/${hadithNumber}`;
    
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
    
    const response = await fetch(url, { headers });
    const data = await response.json();
    
    return data.data;
  } catch (error) {
    console.error(`خطأ في الحصول على الحديث رقم ${hadithNumber} من ${collection}:`, error);
    throw error;
  }
};

/**
 * البحث في الأحاديث
 * @param {string} query - نص البحث
 * @param {string} collection - معرف الكتاب (اختياري)
 * @param {number} page - رقم الصفحة
 * @param {number} limit - عدد النتائج في الصفحة
 * @returns {Promise} وعد يحتوي على نتائج البحث
 */
export const searchHadith = async (query, collection = null, page = 1, limit = 20) => {
  try {
    let url = `${Config.api.hadithApi}/hadiths/search?q=${encodeURIComponent(query)}&page=${page}&limit=${limit}`;
    
    // إذا تم تحديد كتاب معين، نضيفه إلى الاستعلام
    if (collection) {
      url += `&collection=${collection}`;
    }
    
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
    
    const response = await fetch(url, { headers });
    const data = await response.json();
    
    return data.data;
  } catch (error) {
    console.error(`خطأ في البحث عن "${query}":`, error);
    throw error;
  }
};

/**
 * حفظ الأحاديث المفضلة
 * @param {Object} hadith - كائن الحديث
 * @param {Object} storage - كائن التخزين المحلي
 */
export const saveFavoriteHadith = async (hadith, storage) => {
  try {
    // الحصول على قائمة الأحاديث المفضلة الحالية
    const favoritesJson = await storage.getItem(Config.storage.keys.favorites);
    let favorites = favoritesJson ? JSON.parse(favoritesJson) : { hadiths: [] };
    
    // التحقق مما إذا كان الحديث موجوداً بالفعل في المفضلة
    const exists = favorites.hadiths.some(h => 
      h.collection === hadith.collection && h.hadithNumber === hadith.hadithNumber
    );
    
    // إذا لم يكن موجوداً، نضيفه إلى القائمة
    if (!exists) {
      favorites.hadiths.push({
        collection: hadith.collection,
        hadithNumber: hadith.hadithNumber,
        text: hadith.text,
        chapter: hadith.chapter,
        book: hadith.book,
        timestamp: new Date().toISOString(),
      });
      
      // حفظ القائمة المحدثة
      await storage.setItem(
        Config.storage.keys.favorites,
        JSON.stringify(favorites)
      );
    }
  } catch (error) {
    console.error('خطأ في حفظ الحديث المفضل:', error);
    throw error;
  }
};

/**
 * الحصول على قائمة الأحاديث المفضلة
 * @param {Object} storage - كائن التخزين المحلي
 * @returns {Promise} وعد يحتوي على قائمة الأحاديث المفضلة
 */
export const getFavoriteHadiths = async (storage) => {
  try {
    const favoritesJson = await storage.getItem(Config.storage.keys.favorites);
    
    if (favoritesJson) {
      return JSON.parse(favoritesJson).hadiths || [];
    }
    
    return [];
  } catch (error) {
    console.error('خطأ في الحصول على الأحاديث المفضلة:', error);
    return [];
  }
};
