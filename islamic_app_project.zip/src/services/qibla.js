// خدمة بوصلة القبلة

import * as Location from 'expo-location';
import * as Sensors from 'expo-sensors';

/**
 * حساب اتجاه القبلة بناءً على موقع المستخدم
 * @param {number} latitude - خط العرض للمستخدم
 * @param {number} longitude - خط الطول للمستخدم
 * @returns {number} زاوية اتجاه القبلة بالدرجات
 */
export const calculateQiblaDirection = (latitude, longitude) => {
  // إحداثيات الكعبة المشرفة
  const KAABA_LAT = 21.422487;
  const KAABA_LNG = 39.826206;
  
  // تحويل الإحداثيات من درجات إلى راديان
  const userLat = toRadians(latitude);
  const userLng = toRadians(longitude);
  const kaabaLat = toRadians(KAABA_LAT);
  const kaabaLng = toRadians(KAABA_LNG);
  
  // حساب اتجاه القبلة باستخدام صيغة المسافة الكبيرة (Great Circle)
  const y = Math.sin(kaabaLng - userLng);
  const x = Math.cos(userLat) * Math.tan(kaabaLat) - Math.sin(userLat) * Math.cos(kaabaLng - userLng);
  
  // الحصول على الزاوية بالراديان ثم تحويلها إلى درجات
  let qiblaAngle = Math.atan2(y, x);
  qiblaAngle = toDegrees(qiblaAngle);
  
  // تعديل الزاوية لتكون بين 0 و 360 درجة
  qiblaAngle = (qiblaAngle + 360) % 360;
  
  return qiblaAngle;
};

/**
 * الحصول على موقع المستخدم الحالي
 * @returns {Promise} وعد يحتوي على إحداثيات المستخدم
 */
export const getUserLocation = async () => {
  try {
    // طلب إذن الوصول إلى الموقع
    const { status } = await Location.requestForegroundPermissionsAsync();
    
    if (status !== 'granted') {
      throw new Error('لم يتم منح إذن الوصول إلى الموقع');
    }
    
    // الحصول على آخر موقع معروف
    const location = await Location.getCurrentPositionAsync({
      accuracy: Location.Accuracy.High,
    });
    
    return {
      latitude: location.coords.latitude,
      longitude: location.coords.longitude,
      accuracy: location.coords.accuracy,
    };
  } catch (error) {
    console.error('خطأ في الحصول على الموقع:', error);
    throw error;
  }
};

/**
 * بدء مراقبة اتجاه البوصلة
 * @param {Function} callback - دالة يتم استدعاؤها عند تغير اتجاه البوصلة
 * @returns {Object} كائن يحتوي على دالة لإيقاف المراقبة
 */
export const startCompassWatch = (callback) => {
  let subscription = null;
  
  const start = async () => {
    try {
      // التحقق من توفر مستشعر البوصلة
      const isAvailable = await Sensors.Magnetometer.isAvailableAsync();
      
      if (!isAvailable) {
        throw new Error('مستشعر البوصلة غير متوفر على هذا الجهاز');
      }
      
      // ضبط معدل تحديث البوصلة (بالمللي ثانية)
      Sensors.Magnetometer.setUpdateInterval(100);
      
      // بدء الاشتراك في تحديثات البوصلة
      subscription = Sensors.Magnetometer.addListener(magnetometerData => {
        const { x, y, z } = magnetometerData;
        
        // حساب اتجاه البوصلة بالدرجات
        let heading = Math.atan2(y, x) * (180 / Math.PI);
        
        // تعديل الزاوية لتكون بين 0 و 360 درجة
        heading = (heading + 360) % 360;
        
        // استدعاء دالة رد الاتصال مع اتجاه البوصلة
        callback(heading);
      });
    } catch (error) {
      console.error('خطأ في بدء مراقبة البوصلة:', error);
      throw error;
    }
  };
  
  // بدء المراقبة
  start();
  
  // إرجاع دالة لإيقاف المراقبة
  return {
    stop: () => {
      if (subscription) {
        subscription.remove();
      }
    },
  };
};

/**
 * حساب المسافة إلى الكعبة المشرفة
 * @param {number} latitude - خط العرض للمستخدم
 * @param {number} longitude - خط الطول للمستخدم
 * @returns {number} المسافة بالكيلومترات
 */
export const calculateDistanceToKaaba = (latitude, longitude) => {
  // إحداثيات الكعبة المشرفة
  const KAABA_LAT = 21.422487;
  const KAABA_LNG = 39.826206;
  
  // نصف قطر الأرض بالكيلومترات
  const EARTH_RADIUS = 6371;
  
  // تحويل الإحداثيات من درجات إلى راديان
  const userLat = toRadians(latitude);
  const userLng = toRadians(longitude);
  const kaabaLat = toRadians(KAABA_LAT);
  const kaabaLng = toRadians(KAABA_LNG);
  
  // حساب المسافة باستخدام صيغة هافرساين (Haversine)
  const dLat = kaabaLat - userLat;
  const dLng = kaabaLng - userLng;
  
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(userLat) * Math.cos(kaabaLat) *
            Math.sin(dLng / 2) * Math.sin(dLng / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = EARTH_RADIUS * c;
  
  return distance;
};

/**
 * تحويل الدرجات إلى راديان
 * @param {number} degrees - الزاوية بالدرجات
 * @returns {number} الزاوية بالراديان
 */
const toRadians = (degrees) => {
  return degrees * (Math.PI / 180);
};

/**
 * تحويل الراديان إلى درجات
 * @param {number} radians - الزاوية بالراديان
 * @returns {number} الزاوية بالدرجات
 */
const toDegrees = (radians) => {
  return radians * (180 / Math.PI);
};
