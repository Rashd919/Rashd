// ملف اختبار وظائف التطبيق الإسلامي

/**
 * اختبار خدمة مواقيت الصلاة
 */
const testPrayerTimesService = async () => {
  try {
    console.log('=== اختبار خدمة مواقيت الصلاة ===');
    
    // استيراد خدمة مواقيت الصلاة
    const { getPrayerTimesByCity, getPrayerTimesByCoordinates, getNextPrayer, getRemainingTime } = require('./src/services/prayerTimes');
    
    // اختبار الحصول على مواقيت الصلاة حسب المدينة
    console.log('اختبار الحصول على مواقيت الصلاة حسب المدينة (عمان، الأردن):');
    const cityTimes = await getPrayerTimesByCity('Amman', 'Jordan');
    console.log('تم الحصول على مواقيت الصلاة بنجاح:');
    console.log('- الفجر:', cityTimes.timings.Fajr);
    console.log('- الظهر:', cityTimes.timings.Dhuhr);
    console.log('- العصر:', cityTimes.timings.Asr);
    console.log('- المغرب:', cityTimes.timings.Maghrib);
    console.log('- العشاء:', cityTimes.timings.Isha);
    
    // اختبار الحصول على مواقيت الصلاة حسب الإحداثيات (عمان، الأردن)
    console.log('\nاختبار الحصول على مواقيت الصلاة حسب الإحداثيات (عمان، الأردن):');
    const coordTimes = await getPrayerTimesByCoordinates(31.9454, 35.9284);
    console.log('تم الحصول على مواقيت الصلاة بنجاح:');
    console.log('- الفجر:', coordTimes.timings.Fajr);
    console.log('- الظهر:', coordTimes.timings.Dhuhr);
    console.log('- العصر:', coordTimes.timings.Asr);
    console.log('- المغرب:', coordTimes.timings.Maghrib);
    console.log('- العشاء:', coordTimes.timings.Isha);
    
    // اختبار الحصول على الصلاة القادمة
    console.log('\nاختبار الحصول على الصلاة القادمة:');
    const nextPrayer = getNextPrayer(cityTimes);
    console.log('الصلاة القادمة:', nextPrayer.name);
    console.log('وقت الصلاة:', nextPrayer.time);
    
    // اختبار حساب الوقت المتبقي للصلاة القادمة
    console.log('\nاختبار حساب الوقت المتبقي للصلاة القادمة:');
    const remainingTime = getRemainingTime(nextPrayer.time);
    console.log('الوقت المتبقي:', remainingTime.hours, 'ساعة,', remainingTime.minutes, 'دقيقة,', remainingTime.seconds, 'ثانية');
    
    console.log('\nتم اختبار خدمة مواقيت الصلاة بنجاح!');
    return true;
  } catch (error) {
    console.error('فشل اختبار خدمة مواقيت الصلاة:', error);
    return false;
  }
};

/**
 * اختبار خدمة بوصلة القبلة
 */
const testQiblaService = () => {
  try {
    console.log('\n=== اختبار خدمة بوصلة القبلة ===');
    
    // استيراد خدمة بوصلة القبلة
    const { calculateQiblaDirection, calculateDistanceToKaaba } = require('./src/services/qibla');
    
    // اختبار حساب اتجاه القبلة من عمان، الأردن
    console.log('اختبار حساب اتجاه القبلة من عمان، الأردن:');
    const qiblaDirection = calculateQiblaDirection(31.9454, 35.9284);
    console.log('اتجاه القبلة:', qiblaDirection.toFixed(2), 'درجة');
    
    // اختبار حساب المسافة إلى الكعبة من عمان، الأردن
    console.log('\nاختبار حساب المسافة إلى الكعبة من عمان، الأردن:');
    const distance = calculateDistanceToKaaba(31.9454, 35.9284);
    console.log('المسافة إلى الكعبة:', distance.toFixed(2), 'كم');
    
    console.log('\nتم اختبار خدمة بوصلة القبلة بنجاح!');
    return true;
  } catch (error) {
    console.error('فشل اختبار خدمة بوصلة القبلة:', error);
    return false;
  }
};

/**
 * اختبار خدمة القرآن الكريم
 */
const testQuranService = async () => {
  try {
    console.log('\n=== اختبار خدمة القرآن الكريم ===');
    
    // استيراد خدمة القرآن الكريم
    const { getSurahs, getSurahVerses, getAudioUrl, searchQuran } = require('./src/services/quran');
    
    // اختبار الحصول على قائمة السور
    console.log('اختبار الحصول على قائمة السور:');
    const surahs = await getSurahs();
    console.log('تم الحصول على', surahs.length, 'سورة');
    console.log('السور الأولى:', surahs.slice(0, 3).map(s => s.name));
    
    // اختبار الحصول على آيات سورة الفاتحة
    console.log('\nاختبار الحصول على آيات سورة الفاتحة:');
    const fatiha = await getSurahVerses(1);
    console.log('عدد آيات سورة الفاتحة:', fatiha.ayahs.length);
    console.log('الآية الأولى:', fatiha.ayahs[0].text);
    
    // اختبار الحصول على رابط ملف صوتي
    console.log('\nاختبار الحصول على رابط ملف صوتي لسورة الفاتحة:');
    const audioUrl = getAudioUrl(1, 'maher');
    console.log('رابط الملف الصوتي:', audioUrl);
    
    // اختبار البحث في القرآن الكريم
    console.log('\nاختبار البحث في القرآن الكريم (كلمة "رحمة"):');
    const searchResults = await searchQuran('رحمة');
    console.log('عدد نتائج البحث:', searchResults.length);
    if (searchResults.length > 0) {
      console.log('نموذج من النتائج:', searchResults[0].text);
    }
    
    console.log('\nتم اختبار خدمة القرآن الكريم بنجاح!');
    return true;
  } catch (error) {
    console.error('فشل اختبار خدمة القرآن الكريم:', error);
    return false;
  }
};

/**
 * اختبار خدمة الأحاديث
 */
const testHadithService = async () => {
  try {
    console.log('\n=== اختبار خدمة الأحاديث ===');
    
    // استيراد خدمة الأحاديث
    const { getHadithBooks, getHadithChapters, getHadithsByChapter, getHadithByNumber, searchHadith } = require('./src/services/hadith');
    
    // اختبار الحصول على قائمة كتب الحديث
    console.log('اختبار الحصول على قائمة كتب الحديث:');
    const books = await getHadithBooks();
    console.log('تم الحصول على', books.length, 'كتاب');
    console.log('الكتب:', books.map(b => b.name));
    
    // اختبار البحث في الأحاديث
    console.log('\nاختبار البحث في الأحاديث (كلمة "نية"):');
    const searchResults = await searchHadith('نية');
    console.log('عدد نتائج البحث:', searchResults.length);
    if (searchResults.length > 0) {
      console.log('نموذج من النتائج:', searchResults[0].text);
    }
    
    console.log('\nتم اختبار خدمة الأحاديث بنجاح!');
    return true;
  } catch (error) {
    console.error('فشل اختبار خدمة الأحاديث:', error);
    return false;
  }
};

/**
 * اختبار خدمة الأذكار
 */
const testAdhkarService = () => {
  try {
    console.log('\n=== اختبار خدمة الأذكار ===');
    
    // استيراد خدمة الأذكار
    const { getMorningAdhkar, getEveningAdhkar } = require('./src/services/adhkar');
    
    // اختبار الحصول على أذكار الصباح
    console.log('اختبار الحصول على أذكار الصباح:');
    const morningAdhkar = getMorningAdhkar();
    console.log('عدد أذكار الصباح:', morningAdhkar.length);
    console.log('نموذج من أذكار الصباح:', morningAdhkar[0].text.substring(0, 50) + '...');
    
    // اختبار الحصول على أذكار المساء
    console.log('\nاختبار الحصول على أذكار المساء:');
    const eveningAdhkar = getEveningAdhkar();
    console.log('عدد أذكار المساء:', eveningAdhkar.length);
    console.log('نموذج من أذكار المساء:', eveningAdhkar[0].text.substring(0, 50) + '...');
    
    console.log('\nتم اختبار خدمة الأذكار بنجاح!');
    return true;
  } catch (error) {
    console.error('فشل اختبار خدمة الأذكار:', error);
    return false;
  }
};

/**
 * اختبار جميع وظائف التطبيق
 */
const testAllFunctions = async () => {
  console.log('بدء اختبار جميع وظائف التطبيق الإسلامي...\n');
  
  // اختبار خدمة مواقيت الصلاة
  const prayerTimesResult = await testPrayerTimesService();
  
  // اختبار خدمة بوصلة القبلة
  const qiblaResult = testQiblaService();
  
  // اختبار خدمة القرآن الكريم
  const quranResult = await testQuranService();
  
  // اختبار خدمة الأحاديث
  const hadithResult = await testHadithService();
  
  // اختبار خدمة الأذكار
  const adhkarResult = testAdhkarService();
  
  // عرض ملخص نتائج الاختبار
  console.log('\n=== ملخص نتائج الاختبار ===');
  console.log('خدمة مواقيت الصلاة:', prayerTimesResult ? 'ناجح' : 'فاشل');
  console.log('خدمة بوصلة القبلة:', qiblaResult ? 'ناجح' : 'فاشل');
  console.log('خدمة القرآن الكريم:', quranResult ? 'ناجح' : 'فاشل');
  console.log('خدمة الأحاديث:', hadithResult ? 'ناجح' : 'فاشل');
  console.log('خدمة الأذكار:', adhkarResult ? 'ناجح' : 'فاشل');
  
  const allPassed = prayerTimesResult && qiblaResult && quranResult && hadithResult && adhkarResult;
  console.log('\nنتيجة الاختبار الإجمالية:', allPassed ? 'جميع الاختبارات ناجحة!' : 'بعض الاختبارات فشلت');
  
  return allPassed;
};

// تنفيذ الاختبارات
testAllFunctions().then(result => {
  console.log('\nاكتمل اختبار وظائف التطبيق الإسلامي.');
});
